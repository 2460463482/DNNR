neural network weight matrix：dnn.net
dnn.net path："/home/wsn/sim_tmp/dnn.net"
result path："/home/wsn/sim_temp/DNNR/"