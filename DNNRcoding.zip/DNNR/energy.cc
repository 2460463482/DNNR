#include "energy.h"
#include <string>
#include <iomanip>
#include "ns3/mobility-module.h"
#include "global.h"

using namespace std;
using namespace ns3;

extern Time netDelay;
extern clock_t lifeTime;
extern int maxPackets;
extern double totalBytesGenerated;
extern uint32_t totalBytesGathered;
extern clock_t simStartRealTime;
extern clock_t simFinishRealTime;
extern string thisSimPath;
extern string exeName;

extern nodestate NS[201];
extern double totalConsumed;
extern double initialJ;
extern double TxPara;
extern double RxPara;
extern uint32_t nDrain;
extern bool firstDrainFlag;
extern uint32_t firstDrainedNodeId;
extern double firstDrainedNodeTime;
extern uint32_t nDrain;
extern double simStopTime;
extern uint32_t pktSize;
extern bool Banim;
extern uint32_t firstDrainedSinkId;
extern AnimationInterface *Panim;
extern double simStopTime;


static InetSocketAddress broadcastAdr = InetSocketAddress(Ipv4Address::GetBroadcast(), 80);
static TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");

namespace ns3 {

NS_LOG_COMPONENT_DEFINE("Energy");

//-------------------------------------------------------------------------------------
void ManualDrainTest(uint32_t index){
	NS[index].remainingJ =pktSize*2*TxPara;
}


//-------------------------------------------------------------------------------------
void BroadcastDrainNotice(Ptr<Node> node){
	NS_LOG_LOGIC(TIME_STAMP_FUC<<"BroadcastDrainNotice from "
			<<GetNodeIpv4Address(node));
	Ipv4Header h;
	h.SetIdentification(drainNotice_Type);
	h.SetSource(GetNodeIpv4Address(node));
	Ptr<Packet> drainNoticePkt = Create<Packet>(0);
	drainNoticePkt->AddHeader(h);
	Ptr<Socket> drainNoticeSocket = Socket::CreateSocket(
			node, tid);
	drainNoticeSocket->Connect(broadcastAdr);
	drainNoticeSocket->SetAllowBroadcast(true);
	drainNoticeSocket->Send(drainNoticePkt);
	drainNoticeSocket->Close();
}

//-------------------------------------------------------------------------------------
void InstallEnergy(NodeContainer senseNodes){
	for (uint32_t i = 0; i < MAX_NUM; i++) {
		NS[i].remainingJ = -1.0;
	}
	for (uint32_t i = 0; i < senseNodes.GetN(); i++) {
		NS[senseNodes.Get(i)->GetId()].remainingJ = initialJ;
	}
}

//-------------------------------------------------------------------------------------
void EnergyFinalRecord(NodeContainer senseNodes,double remaingJ[]){
		std::stringstream ss;
		std::stringstream si;
		ss << "/home/wsn/sim_temp/pOLSR/"<<maxPackets<<"-final.record";
		std::ofstream of(ss.str().c_str());
		ss << std::endl << "Initial energy = " << initialJ << std::endl;

		ss << std::endl << "开始时间:" << simStartRealTime << std::endl;
		ss << std::endl << "结束时间: " << simFinishRealTime << std::endl;
		ss << std::endl << "发送数据量:" << totalBytesGenerated << std::endl;
		ss << std::endl << "接收数据量:" << totalBytesGathered << std::endl;
		ss << std::endl << "系统吞吐量: " << totalBytesGathered*1.0/((simFinishRealTime-simStartRealTime)/1000)<<"(Byte/s)" << std::endl;
		ss << std::endl << "系统PDR指标:" << totalBytesGathered/totalBytesGenerated*100<<"%" << std::endl;
		ss << "Total comsumed energy = " << totalConsumed <<std::endl;

		ss << std::setw(15) << std::left << "Node Number";
		ss << std::setw(15) << std::left << "Remaining" << std::endl;
		ss << std::setw(15) << std::left << "(global)";
		ss << std::setw(25) << std::left << "Energy" << std::endl;

		uint32_t nodenum = senseNodes.GetN();
		for (uint32_t i = 0; i < nodenum; i++) {
			si << std::setw(15) << std::left << senseNodes.Get(i)->GetId();
			si << std::setw(15) << std::left
					<< NS[senseNodes.Get(i)->GetId()].remainingJ << std::endl;
			ss << si.str();
			si.str("");
			si.clear();
		}
		ss << "Total comsumed energy = " << totalConsumed;
		cout<<"Total comsumed energy = " << totalConsumed<<endl;
		NS_LOG_INFO(ss.str().c_str());
		of << ss.str().c_str();
		of.close();
}

//-------------------------------------------------------------------------------------
bool CheckRemainingJ(Ptr<Node> n, Ptr<Packet> pkt) {
	uint32_t id = n->GetId();
	return NS[id].remainingJ >= pkt->GetSize() * TxPara;
}

//-------------------------------------------------------------------------------------
bool CheckRemainingJ(Ptr<Node> n) {
	uint32_t id = n->GetId();
	return NS[id].remainingJ >= pktSize * TxPara;
}


//-------------------------------------------------------------------------------------
void UpdateNodesColorByEnergy(Ptr<Node> n, double per){
	if (per < 1 && per >= 0.9) {
		Panim->UpdateNodeColor(n, 200, 0, 0);
	} else if (per < 0.9 && per >= 0.5) {
		Panim->UpdateNodeColor(n, 150, 0, 0);
	} else if (per < 0.5 && per >= 0.25) {
		Panim->UpdateNodeColor(n, 100, 0, 0);
	} else {
		Panim->UpdateNodeColor(n, 50, 0, 0);
	}
}

//-------------------------------------------------------------------------------------
void UpdateEnergySources(Ptr<Node> n, Ptr<Packet> p, uint16_t flag,NodeContainer mobileSinkNode) {
	uint32_t id = n->GetId();
	uint32_t thisPktSize = p->GetSize();
	double oldValue = NS[id].remainingJ;
	double newValue = oldValue;
	double consumedJ;
	NS_ASSERT(oldValue > 0);
	switch (flag) {
		case 0: {
			thisPktSize=p->GetSize();
			consumedJ=thisPktSize * TxPara;
			newValue = newValue - consumedJ;
			if (newValue <= pktSize * TxPara) {
				NS_LOG_DEBUG(
						TIME_STAMP_FUC<<"Node["<<id<<"]'s energy used up on transmission");
				if (Banim) {
					Panim->UpdateNodeColor(n, 0, 0, 0);
				}
				NS[id].remainingJ = 0;
				totalConsumed+=oldValue;
				if (firstDrainFlag) {
					firstDrainedNodeId = id;
					firstDrainedNodeTime = Simulator::Now().GetSeconds();
					firstDrainFlag=false;
				}
				NS_LOG_DEBUG(
						TIME_STAMP_FUC<<"Node["<<id<<"] is a sinkNode, stop the simulation");
				firstDrainedSinkId = id;
				nDrain++;
				DoDrainRecord(n);
				simStopTime = Simulator::Now().GetSeconds();
				lifeTime=Simulator::Now().GetSeconds();
				Simulator::Stop();
			} else {
				NS[id].remainingJ = newValue;
				totalConsumed+=consumedJ;

				if (Banim) {
					double remainingPer = NS[id].remainingJ / initialJ;
					UpdateNodesColorByEnergy(n, remainingPer);
				}
			}
			break;
		}
		case 1: {
			consumedJ=thisPktSize * RxPara;
			newValue = newValue - consumedJ;
			if (newValue <= pktSize * RxPara) {
				NS_LOG_DEBUG(
						TIME_STAMP_FUC<<"Node["<<id<<"]'s energy used up on reception");
				if (Banim) {
					Panim->UpdateNodeColor(n, 0, 0, 0);
				}
				NS[id].remainingJ = 0;
				totalConsumed+=oldValue;
				if (firstDrainFlag) {
					firstDrainedNodeId = id;
					firstDrainedNodeTime = Simulator::Now().GetSeconds();
					firstDrainFlag=false;
				}
				NS_LOG_DEBUG(
								TIME_STAMP_FUC<<"Node["<<id<<"] is a sinkNode, stop the simulation");
				firstDrainedSinkId = id;
				nDrain++;
				DoDrainRecord(n);
				simStopTime = Simulator::Now().GetSeconds();

				lifeTime=Simulator::Now().GetSeconds();
				Simulator::Stop();
			} else {
				NS[id].remainingJ = newValue;
				totalConsumed+=consumedJ;
				if (Banim) {
					double remainingPer = NS[id].remainingJ / initialJ;
					UpdateNodesColorByEnergy(n, remainingPer);
				}
			}
			break;
		}
		default: {
			break;
		}
	}
}

//-------------------------------------------------------------------------------------
void DoDrainRecord(Ptr<Node> thisNode){
	stringstream ss,si;
	ss << thisSimPath << exeName << "-drain.record";
	ofstream of;
	of.open(ss.str().c_str(), ios::app);
	ss.str("");
	ss.clear();

	double timeNow=Simulator::Now().GetSeconds();
	Ipv4Address thisAdr=GetNodeIpv4Address(thisNode);
	si<<thisAdr;
	uint32_t thisId=thisNode->GetId();

	ss<<setw(10)<<left<<timeNow;

	ss<<setw(15)<<left<<si.str();
	si.str("");
	si.clear();
	ss<<setw(5)<<left<<thisId;
	ss<<endl;
	of<<ss.str().c_str();
	ss.str("");
	ss.clear();
}


}
