#include "ns3/flow-monitor-module.h"
#include "ns3/aodv-module.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/config-store-module.h"
#include "ns3/wifi-module.h"
#include "ns3/energy-module.h"
#include "ns3/internet-module.h"
#include "ns3/netanim-module.h"
#include "ns3/applications-module.h"

#include "math.h"
#include "time.h"
#include "stdlib.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <map>
#include <stack>
#include <string>
#include <iomanip>
#include <fann/fann.h>
#include <cmath>

#include "global.h"
#include "energy.h"
#include "final_record.h"
#include "BSBroadcast.h"
#include "packet_manage.h"


using namespace ns3;
using namespace std;

//-------------------------------------------------------------------------------------
NS_LOG_COMPONENT_DEFINE("DNNRScript");
uint32_t receivepacket = 0;



int BSreceiveMore2=0;
int received=0;
int deleteCacheTimes=0;



int replyOverDis=0;
int receiveMore2=0;
int transState[201][201]={0};


int tmpReply = 0;
int tmpRecv = 0;
double caculateTime = 0;
int countnum = 0;
bool isRetry[5001];
vector<vector<double> >recvRatio;

//-------------------------------------------------------------------------------------
const unsigned int num_input = 8;
const unsigned int num_output = 1;	
const unsigned int num_layers = 6;
const unsigned int num_neurons_hidden1 = 10;
const unsigned int num_neurons_hidden2 = 8;
const unsigned int num_neurons_hidden3 = 6;
const unsigned int num_neurons_hidden4 = 4;
const float desired_error = (const float)0.00001;
const unsigned int max_epochs = 500;
const unsigned int epochs_between_reports = 50;  
struct fann_train_data* data;	
struct fann* ann;

//-------------------------------------------------------------------------------------


void buildMapIdAdr();
void initial();
void updateNeighborTable();
void update();



//-------------------------------------------------------------------------------------

int JumpsArry[6000];
int isPktReceived[6000]={0};
vector <int> validJumps;
double para3D;
clock_t lifeTime;
string mobilityModel="";
bool isLifeCycle=false;
int inputSpeed = 50;
int moveSpeed=50;
int netSizeXY = 1000;
int netSizeZ = 500;
int err = 0;
bool isSpeed=false;
bool updateDone=false;
double dataInterval = 16;
double updateInterval = 16;	
double maxDis = 225.0;	
double buildNeighborDone = 2.0;  
uint32_t nNodes = 200;
int maxPackets = 3000;

//-------------------------------------------------------------------------------------
static TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
static InetSocketAddress broadcastAdr = InetSocketAddress(Ipv4Address::GetBroadcast(), 80);
static std::string phyMode("DsssRate11Mbps");
static double Prss = -80; 
static double offset = 81;  

//-------------------------------------------------------------------------------------
double totalTime = 9999.0; 
clock_t simStartRealTime;
clock_t simFinishRealTime;
double simStopTime=0.0;
int UnitPacketNum = 200;
stringstream ssi;
double maxX;
double maxY;
double mSinkTraceY;
bool gridTest=true;
uint32_t pktSize = 1024;  
double totalBytesGenerated;
double initialJ = 5.0*1e9;
double totalConsumed=0;
uint32_t energyTraceIndex=0;

double TxPara = 0.000006;
double RxPara = 0.000006;

uint32_t nDrain=0;
double Tgather=0.65;

//-------------------------------------------------------------------------------------

nodestate NS[201];
int BSRoundNum;
double Node_Vx[201];
double Node_Vy[201];
double Node_Vz[201];
double Node_Lx[201];
double Node_Ly[201];
double Node_Lz[201];
int Node_level[201];
uint32_t transTime[201];
uint32_t transTime1[201];
double node_delay[201][201];
bool reliableArea[201][201];
uint32_t BSSendTime;
vector<double>delay;
double netDelay;
vector<vector<double> >instSpeed;
vector<vector<double> >trans;


//-------------------------------------------------------------------------------------
bool Banim=false;
bool Brotate=true;
bool Bdrain=true;
bool isStatic = true;
AnimationInterface *Panim = 0;
uint32_t firstDrainedNodeId=0;
bool firstDrainFlag=true;
uint32_t firstDrainedSinkId=0;
double firstDrainedNodeTime=0;
string thisSimPath;
string exeName="EXORMain";
string simFolderName="/home/wsn/sim_temp/DNNR";
vector<int>hps;
uint32_t totalBytesGathered;
double totalEnergyConsumed;
double networkLifetime;
double dataGatherPercentage=1.0;
double RngRun;
double simRunTime;
double EnergyConsumeRate;
uint32_t totalJumps;
double sinkVariance;
bool rewrite = false;
string timeStr;

//-------------------------------------------------------------------------------------
NodeContainer senseNodes;
NodeContainer mobileSinkNode;
NetDeviceContainer senseDevices;
NetDeviceContainer mobileSinkDevice;
Ipv4InterfaceContainer senseIfs;
Ipv4InterfaceContainer mobileSinkIf;
double remaingJ[MAX_NUM];
set<uint32_t>remains;
GraphList graph;
int send = 0;
map<uint32_t,Ipv4Address>mapIdAdr;




//-------------------------------------------------------------------------------------
void RecvPacketCallback(Ptr<Socket> socket) {
	Ptr<Packet> pkt;
	Address from;
	while ((pkt = socket->RecvFrom(from))) {
		Ptr<Packet> packet = pkt->Copy();
		nodeType nType;
		pktType pType;
		if (packet->GetSize() > 0) {
			Ptr<Node> thisNode = socket->GetNode();
			Ipv4Header h;
			packet->PeekHeader(h);
			packet->RemoveHeader(h);
			uint32_t idf = thisNode->GetId();
			pType = pktType(h.GetIdentification());
			nType = CheckNodeType(thisNode,senseNodes,mobileSinkNode.Get(0));
			switch (nType) {
			case mobileSink_Type: {	
				switch (pType) {
					case dataGathering_Type:

						break;
					case data_Type:
					{
						int sendNum = 0;
						uint32_t sendTime = 0;
						stringstream recvData;
						packet->CopyData(&recvData, packet->GetSize());	
						uint32_t nodeID = AnalyzeDataPacket(recvData, sendNum, sendTime);
						if(transState[nodeID][thisNode->GetId()]==1)
	 						receiveMore2++;
						else
							transState[nodeID][thisNode->GetId()]=1;
						JumpsArry[sendNum-1]++;
						validJumps.push_back(JumpsArry[sendNum-1]);
						JumpsArry[sendNum-1]=0;
						if (isRetry[sendNum]&& Simulator::Now().GetMicroSeconds() - sendTime < 20000) {
							delay.push_back(Simulator::Now().GetMicroSeconds() - sendTime);
						}
						Ptr<Node> fromNode = GetNodePtrFromGlobalId(nodeID, senseNodes, mobileSinkNode);
						Ptr<Node>sourceNode = GetNodePtrFromIpv4Adr(h.GetSource(),senseNodes,mobileSinkNode);
						if(isPktReceived[sendNum-1]!=1){
							totalBytesGathered += pktSize;
							isPktReceived[sendNum-1]=1;
							receivepacket = receivepacket + 1;
						}
						else{
							BSreceiveMore2++;
							}
						SendReplyTransPacket(thisNode, fromNode, sendNum,sourceNode->GetId());
						tmpReply++;

					}
					break;
					case REQ_Type:
						{
							Ptr<Node>sourceNode = GetNodePtrFromIpv4Adr(h.GetSource(),senseNodes,mobileSinkNode);
							Vector location2;
							if (isStatic){
								location2 = sourceNode->GetObject<MobilityModel>()->GetPosition();
							}else{
								location2 = sourceNode->GetObject<MobilityModel>()->GetPosition();
							}
							Ptr<Node>msNode = mobileSinkNode.Get(0);
							Vector location1 = msNode->GetObject<MobilityModel>()->GetPosition();
							double weight=GetdistanOf2Nodes(location2,location1);
							graph.addNewEdgeToList(GetNodePtrFromIpv4Adr(h.GetSource(),senseNodes,mobileSinkNode)->GetId(),weight,mobileSinkNode.Get(0)->GetId());
						}
						break;
					case BS_Location_Type:
					{
						Ptr<Node>sourceNode = GetNodePtrFromIpv4Adr(h.GetSource(), senseNodes, mobileSinkNode);
						Vector location2;
						if (isStatic) {
							location2 = sourceNode->GetObject<MobilityModel>()->GetPosition();
						}
						else {
							location2 = sourceNode->GetObject<MobilityModel>()->GetPosition();
						}
						Ptr<Node>msNode = mobileSinkNode.Get(0);
						Vector location1 = msNode->GetObject<MobilityModel>()->GetPosition();
						double weight = GetdistanOf2Nodes(location2, location1);
						graph.addNewEdgeToList(GetNodePtrFromIpv4Adr(h.GetSource(), senseNodes, mobileSinkNode)->GetId(), weight, mobileSinkNode.Get(0)->GetId());
					}

						break;
					default:
						break;
					}
				break;
			}
			case sense_Type: {
				switch (pType) {
					case data_Type: {
						int sendNum = 0;
						uint32_t sendTime = 0;	
						stringstream recvData;
						packet->CopyData(&recvData, packet->GetSize());			
						uint32_t nodeID = AnalyzeDataPacket(recvData, sendNum, sendTime);
						if(transState[nodeID][thisNode->GetId()]==1)
	 						receiveMore2++;
						else
							transState[nodeID][thisNode->GetId()]=1;
						JumpsArry[sendNum-1]++;
						if (JumpsArry[sendNum - 1] >= 10) {
							break;
						}
						received++;
						double oldValuef = NS[idf].remainingJ;
						uint32_t thispktsize = 1024;
						double consumedJf = 50 * 0.000000001 * 1e9 * thispktsize;
						if (oldValuef > consumedJf) {
							NS[idf].remainingJ -= consumedJf;
							totalConsumed = totalConsumed + consumedJf;
						}
						else {
							NS[idf].isdead = true;
							NS[idf].remainingJ = 0;
						}
						Ptr<Node> fromNode = GetNodePtrFromGlobalId(nodeID, senseNodes, mobileSinkNode);
						Ptr<Node>sourceNode = GetNodePtrFromIpv4Adr(h.GetSource(),senseNodes,mobileSinkNode);
						Vector location1 = thisNode->GetObject<MobilityModel>()->GetPosition();
						Vector location2 = fromNode->GetObject<MobilityModel>()->GetPosition();
						double distance1 =GetdistanOf2Nodes(location1,location2);
						if(distance1>maxDis)
							replyOverDis++;	
						Ptr<Node>msNode = mobileSinkNode.Get(0);
						SendReplyTransPacket(thisNode, fromNode, sendNum,sourceNode->GetId());
						tmpReply++;
						if(thisNode->GetId()==GetNodePtrFromIpv4Adr(h.GetSource(),senseNodes,mobileSinkNode)->GetId())
							break;
						ProcessDataPacket(thisNode, packet, h);
						break;
					}
					case BS_Location_Type: {
							ProcessLocationPacket(thisNode, packet);
							uint32_t curId = thisNode->GetId();
							Ipv4Address src = h.GetSource();
							Ptr<Node>node = GetNodePtrFromIpv4Adr(src,senseNodes,mobileSinkNode);
							Ptr<Node>msNode = mobileSinkNode.Get(0);
							uint32_t id = node->GetId();
							Vector location1;
							Vector location2;
							if (isStatic){
								location1 = thisNode->GetObject<MobilityModel>()->GetPosition();
								location2 = node->GetObject<MobilityModel>()->GetPosition();
							}else{
								location1 = thisNode->GetObject<MobilityModel>()->GetPosition();
								location2 = node->GetObject<MobilityModel>()->GetPosition();
							}	
							Vector location = msNode->GetObject<MobilityModel>()->GetPosition();
							double oldValuef = NS[idf].remainingJ;
							uint32_t thispktsize = 100;
							double consumedJf = 50 * 0.000000001 * 1e9 * thispktsize;
							if (oldValuef > consumedJf) {
								NS[idf].remainingJ -= consumedJf;
								totalConsumed = totalConsumed + consumedJf;
							}
							else {
								NS[idf].isdead = true;
								NS[idf].remainingJ = 0;
							}
							double distance1 = GetdistanOf2Nodes(location1,location);
							double distance2 = GetdistanOf2Nodes(location2,location);
							if (distance1 < distance2) {
								graph.addNewEdgeToList(id,GetdistanOf2Nodes(location1,location2),curId);
							}
							break;
					}
					case Reply_Trans_Type: {
						tmpRecv++;
						uint32_t n_ID = 0;
						stringstream recvData;
						int sendNum = 0;
						packet->CopyData(&recvData, packet->GetSize());	
						uint32_t sourceId = AnalyzeReplyPacket(recvData, sendNum, n_ID);
						vector<dataCache>::iterator it;
 						for(it=NS[thisNode->GetId()].nodeCache.begin();it!=NS[thisNode->GetId()].nodeCache.end();){
							if(it->sourceId==sourceId&&it->sendNum==sendNum){
								it->isReceReply=true;
								it=NS[thisNode->GetId()].nodeCache.erase(it);
								deleteCacheTimes++;
								break;
							}
							else
								it++;
						}
						recvRatio[thisNode->GetId()][n_ID] = 0.05 + (1 - 0.05) * recvRatio[thisNode->GetId()][n_ID];
						recvRatio[n_ID][thisNode->GetId()] = recvRatio[thisNode->GetId()][n_ID];
						double oldValuef = NS[idf].remainingJ;
						uint32_t thispktsize = 100;
						double consumedJf = 50 * 0.000000001 * 1e9 * thispktsize;
						if (oldValuef > consumedJf) {
							NS[idf].remainingJ -= consumedJf;
							totalConsumed = totalConsumed + consumedJf;
						}
						else {
							NS[idf].isdead = true;
							NS[idf].remainingJ = 0;
						}						
						break;
					}
					case REQ_Type: {
						uint32_t curId = thisNode->GetId();
						Ipv4Address src = h.GetSource();
						Ptr<Node>node = GetNodePtrFromIpv4Adr(src,senseNodes,mobileSinkNode);
						Ptr<Node>msNode = mobileSinkNode.Get(0);
						uint32_t id = node->GetId();
						double oldValuef = NS[idf].remainingJ;
						uint32_t thispktsize = 50;
						double consumedJf = 50 * 0.000000001 * 1e9 * thispktsize;
						if (oldValuef > consumedJf) {
							NS[idf].remainingJ -= consumedJf;
							totalConsumed = totalConsumed + consumedJf;
						}
						else {
							NS[idf].isdead = true;
							NS[idf].remainingJ = 0;
						}
						Vector location1;
						Vector location2;
						if (isStatic){
							location1 = thisNode->GetObject<MobilityModel>()->GetPosition();
							location2 = node->GetObject<MobilityModel>()->GetPosition();
						}else{
							location1 = thisNode->GetObject<MobilityModel>()->GetPosition();
							location2 = node->GetObject<MobilityModel>()->GetPosition();
						}	
						ProcessNodePacket(thisNode, node, packet);
						Vector location = msNode->GetObject<MobilityModel>()->GetPosition();
						double distance1 = GetdistanOf2Nodes(location1,location);
						double distance2 = GetdistanOf2Nodes(location2,location);
						if(distance1<distance2){
							graph.addNewEdgeToList(id,GetdistanOf2Nodes(location1,location2),curId);
						}
						break;
					}
					default: {
						break;
					}
				}
				break;
			}
			default:
				break;
			}
		}
	}
}




//-------------------------------------------------------------------------------------
void setLog(){
	LogComponentEnable("DNNRScript", LOG_LEVEL_DEBUG);
	LogComponentEnable("Energy", LOG_LEVEL_DEBUG);
	LogComponentEnable("AdhocWifiMac", LOG_LEVEL_DEBUG);
}

//-------------------------------------------------------------------------------------
void netSet(){
	Config::SetDefault("ns3::WifiRemoteStationManager::FragmentationThreshold",
			StringValue("2200"));
	Config::SetDefault("ns3::WifiRemoteStationManager::RtsCtsThreshold",
			StringValue("2200"));
	Config::SetDefault("ns3::WifiRemoteStationManager::NonUnicastMode",
			StringValue(phyMode));
}

//-------------------------------------------------------------------------------------
void createNode() {
	senseNodes.Create(nNodes);
	for (NodeContainer::Iterator itr = senseNodes.Begin(); itr != senseNodes.End(); itr++) {
		uint32_t id = (*itr)->GetId();
		NS[id].remainingJ = initialJ;
	}
	mobileSinkNode.Create(1);
	for (NodeContainer::Iterator itr = mobileSinkNode.Begin(); itr != mobileSinkNode.End(); itr++) {
		uint32_t id = (*itr)->GetId();
		NS[id].remainingJ = 10 * initialJ;
	}
	NS_LOG_DEBUG("Create nodes done!");
}

//-------------------------------------------------------------------------------------
void createMobilityModel() {
	MobilityHelper mobility;
    stringstream nodeSpeed;
    stringstream msSpeed;
    stringstream inputSizeXY;
    stringstream inputSizeZ;
    nodeSpeed<<"ns3::UniformRandomVariable[Min="<< 1<<"|Max="<<moveSpeed<<"]";
    msSpeed<<"ns3::ConstantRandomVariable[Constant="<<inputSpeed<<"]";
    inputSizeXY<<"ns3::UniformRandomVariable[Min="<<0<<"|Max="<<netSizeXY<<"]";
    inputSizeZ<<"ns3::UniformRandomVariable[Min="<<0<<"|Max="<<netSizeZ<<"]";
	ObjectFactory pos1;
	pos1.SetTypeId("ns3::RandomBoxPositionAllocator");
	pos1.Set("X", StringValue(inputSizeXY.str()));
	pos1.Set("Y", StringValue(inputSizeXY.str()));
	pos1.Set("Z", StringValue(inputSizeZ.str()));
	Ptr<PositionAllocator> taPositionAlloc1 = pos1.Create()->GetObject<PositionAllocator>();


	mobility.SetMobilityModel("ns3::RandomWaypointMobilityModel",
		"Speed", StringValue(msSpeed.str()),
		"Pause", StringValue("ns3::ConstantRandomVariable[Constant=2.0]"),
		"PositionAllocator", PointerValue(taPositionAlloc1)
	);
	mobility.Install(mobileSinkNode);

	mobility.SetPositionAllocator("ns3::RandomBoxPositionAllocator", "X", StringValue (inputSizeXY.str()),
																"Y", StringValue (inputSizeXY.str()),
																"Z", StringValue (inputSizeZ.str()));

    mobility.SetMobilityModel("ns3::RandomWaypointMobilityModel",
		"Speed", StringValue(nodeSpeed.str()),
		"Pause", StringValue("ns3::ConstantRandomVariable[Constant=2.0]"),
		"PositionAllocator", PointerValue(taPositionAlloc1)
	);
	mobility.Install(senseNodes);
	Ptr<MobilityModel> mm = mobileSinkNode.Get(0)->GetObject<MobilityModel>();
	Vector BSposition;
    BSposition.x=0.5*netSizeXY;
    BSposition.y=0.5*netSizeXY;
    BSposition.z=0.5*netSizeZ;
	mm->SetPosition(BSposition);

	NS_LOG_DEBUG("Install mobility done!");
}

//-------------------------------------------------------------------------------------
void createWifiDevice(){
	stringstream ssi;
	WifiHelper wifi;
	wifi.SetStandard(WIFI_PHY_STANDARD_80211b);
	YansWifiPhyHelper wifiPhy = YansWifiPhyHelper::Default();
	wifiPhy.Set("RxGain", DoubleValue(-10));
	wifiPhy.Set("TxGain", DoubleValue(offset + Prss));
	wifiPhy.Set("CcaMode1Threshold", DoubleValue(0.0));
	YansWifiChannelHelper wifiChannel;
	wifiChannel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
	wifiChannel.AddPropagationLoss("ns3::RangePropagationLossModel", "MaxRange",
			DoubleValue(maxDis));
	Ptr<YansWifiChannel> wifiChannelPtr = wifiChannel.Create();
	wifiPhy.SetChannel(wifiChannelPtr);
	NqosWifiMacHelper wifiMac = NqosWifiMacHelper::Default();
	wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager", "DataMode",
			StringValue(phyMode), "ControlMode", StringValue(phyMode));
	wifiMac.SetType("ns3::AdhocWifiMac");
	senseDevices = wifi.Install(wifiPhy, wifiMac, senseNodes);
	mobileSinkDevice = wifi.Install(wifiPhy, wifiMac, mobileSinkNode);
	ssi<<thisSimPath<<exeName;
	wifiPhy.EnablePcap(ssi.str().c_str(), mobileSinkNode.Get(0)->GetId(), 0, true);
	ssi.str("");
	ssi.clear();
	NS_LOG_DEBUG("Create devices done!");
}

//-------------------------------------------------------------------------------------
void installInternetStack(){
	InternetStackHelper stack2;
	stack2.Install (mobileSinkNode);
	stack2.Install (senseNodes);
	Ipv4AddressHelper ipv4;
	ipv4.SetBase("10.1.1.0", "255.255.255.0");
	senseIfs = ipv4.Assign(senseDevices);
	mobileSinkIf = ipv4.Assign(mobileSinkDevice);
	NS_LOG_DEBUG("Install Internet stack done!");
}

//-------------------------------------------------------------------------------------
void createSocketCallBack(){
	vector<Ptr<Socket> > recvSocket(nNodes+1);
	recvSocket[0] = Socket::CreateSocket(mobileSinkNode.Get(0),tid);
	recvSocket[0]->Bind(InetSocketAddress(mobileSinkIf.GetAddress(0), 80));
	recvSocket[0]->SetRecvCallback(MakeCallback(&RecvPacketCallback));
	for (uint32_t i = 1; i < nNodes+1; i++) {
		recvSocket[i] = Socket::CreateSocket(senseNodes.Get(i-1), tid);
		recvSocket[i]->Bind(InetSocketAddress(senseIfs.GetAddress(i-1), 80));
		recvSocket[i]->SetRecvCallback(MakeCallback(&RecvPacketCallback));
	}
	NS_LOG_DEBUG("Set recvSocket done!");
}




//-------------------------------------------------------------------------------------
void buildMapIdAdr(){
	mapIdAdr.clear();
	pair<uint32_t,Ipv4Address>pairNode;
	for (NodeContainer::Iterator i = senseNodes.Begin(); i != senseNodes.End();
	i++) {
		Ptr<Node> thisNode = *i;
		uint32_t id = thisNode->GetId();
		Ipv4Address sourceAdr = GetNodeIpv4Address(thisNode);
		pairNode.first = id;
		pairNode.second = sourceAdr;
		mapIdAdr.insert(pairNode);
	}
	Ptr<Node>msNode = mobileSinkNode.Get(0);
	mapIdAdr.insert(pair<uint32_t,Ipv4Address>(msNode->GetId(),GetNodeIpv4Address(msNode)));
}

//-------------------------------------------------------------------------------------
void initial(){
	for (NodeContainer::Iterator i = senseNodes.Begin();
			i != senseNodes.End(); i++) {
		Ptr<Node>node = *i;
		remains.insert(node->GetId());
	}
	graph.m_vCount = nNodes;
	graph.makeVertexArray();
	recvRatio.resize(nNodes, vector<double>(nNodes));
	for (int i = 0; i <(int)nNodes; i++) {
		for (int j = 0; j < (int)nNodes; j++) {
			recvRatio[i][j] = 0.5;
		}
	}
	for (int i = 0; i < 5001; i++) {
		isRetry[i] = true;
	}
}

//-------------------------------------------------------------------------------------
void update() {
	updateDone = false;
	for (NodeContainer::Iterator i = senseNodes.Begin();
		i != senseNodes.End(); i++) {
		Ptr<Node>node = *i;
		graph.clearNode(node->GetId());
	}
	for (uint32_t i = 0; i <= nNodes; i++) {
			NS[i].RecvBSBroadcast = false;
			NS[i].isSignNode= false;
			NS[i].NodeLevel = 0;
			NS[i].BSNum = 0;
	}
	Simulator::Schedule(Seconds(0),&BsBroadcast,mobileSinkNode.Get(0));
	Simulator::Schedule(Seconds(0.5), &updateNeighbor);
	Simulator::Schedule(Seconds(buildNeighborDone),&getNeighNum);
	Simulator::Schedule(Seconds(buildNeighborDone), &setUpdateDoneFlag, true);
	Simulator::Schedule(Seconds(buildNeighborDone), &DataToSink);
	Simulator::Schedule(Seconds(updateInterval), &update);
}

void updateNeighborTable(){
	graph.updateArray();
}


void setSimStartTime(){
	simStartRealTime = clock();
}

//-------------------------------------------------------------------------------------
double GetdistanFromMSink(Ptr<Node> srcN) {
	Vector srcP;
	if(isStatic){
		srcP = srcN->GetObject<MobilityModel>()->GetPosition();
	}else{
		srcP = srcN->GetObject<MobilityModel>()->GetPosition();
	}
	Ptr<Node>msNode = mobileSinkNode.Get(0);
	Ptr<MobilityModel> remCpmm = msNode->GetObject<MobilityModel>();
	Vector remP = remCpmm->GetPosition();
	return std::sqrt((srcP.x - remP.x)*(srcP.x - remP.x) + (srcP.y - remP.y)*(srcP.y - remP.y)+(srcP.z - remP.z)*(srcP.z - remP.z));
}


//-------------------------------------------------------------------------------------
int main(int argc, char* argv[]) {
	double simStartTime = 0.0; 
	CommandLine cmd;
	cmd.AddValue("nNodes", "Number of Nodes", nNodes);
	cmd.AddValue("isSpeed","is Speed", isSpeed);
	cmd.AddValue("moveSpeed","move Speed", moveSpeed);
    cmd.AddValue("netSizeXY", "size of network(x,y)", netSizeXY);
    cmd.AddValue("netSizeZ", "size of network(z)", netSizeZ);
    cmd.AddValue("inputSpeed","input speed",inputSpeed);
	cmd.AddValue("mobilityModel","use mobilityModel", mobilityModel);
	cmd.AddValue("isLifeCycle","is test lifeCycle", isLifeCycle);
	cmd.AddValue("totalTime", "Simulation time length", totalTime);
	cmd.AddValue("simStartTime", "Simulation start time", simStartTime);
	cmd.AddValue("maxDis", "max distance to transmit", maxDis);
	cmd.AddValue("maxPackets", "max distance to transmit", maxPackets);
	cmd.AddValue("initialJ","Initial energy of each BaiscEnergySource", initialJ);
	cmd.AddValue("rewrite", "Whether to rewrite the result-sptMain.record",rewrite);
	cmd.AddValue("pktSize","Size of data packe",pktSize);
	cmd.AddValue("gridTest","Whether to use grid tes",gridTest);
	cmd.AddValue("Banim","Whether to generate animatit",Banim);
	cmd.AddValue("energyTraceIndex","The global id of node to trace energy",energyTraceIndex);
	cmd.AddValue("dataInterval","The time interval of data generation",dataInterval);
	cmd.AddValue("Brotate","Whether to enable gateway rotation ",Brotate);
	cmd.AddValue("Bdrain","Whether to enable drain notice broadcast ",Bdrain);
	cmd.AddValue("isStatic","Whether install static mobilitymodel ",isStatic);
	cmd.AddValue("Tgather","The percentage of threshold of data gathering percentage,(0,1) ",Tgather);
	cmd.Parse(argc, argv);
	NS_LOG_DEBUG("Configure done!");
	mSinkTraceY = maxY/2; 

	simStopTime=totalTime;
	setLog();
	netSet();
	setSimStartTime();
	createNode();
	createMobilityModel();
	createWifiDevice();
	installInternetStack();
	createSocketCallBack();

	Ptr<FlowMonitor> flowMonitor;    
	FlowMonitorHelper flowHelper;    
	flowMonitor = flowHelper.InstallAll();  
	buildMapIdAdr();

	ann = fann_create_from_file("/home/wsn/sim_tmp/dnn.net");
	
	initial(); 
	Simulator::Schedule(Seconds(0.1),&update);   
	Simulator::Stop(Seconds(totalTime));
	Simulator::Run();

	finalRecord();
	Simulator::Destroy();
	return 0;
}





