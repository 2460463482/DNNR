#ifndef PACKET_MANAGE_H
#define PACKET_MANAGE_H
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/network-module.h"
#include "ns3/node-container.h"
#include "global.h"
#include "energy.h"
#include "GraphList.h"
#include "BSBroadcast.h"
#include <iomanip>
#include <fstream>
using namespace std;
namespace ns3 {

    void TransmitDataPacket(Ptr<Node> localNode, Ipv4Address sourceAdr,	Ipv4Address sinkAdr,int sendNum, uint32_t Node_SendTime);
    void DataToSink();
    void DataToSinkSecond();
    int getNeighNum1(uint32_t neighId);
    void sendCache(Ptr<Node> thisNode);
    void deleteInvalidCache(Ptr<Node> thisNode);
    void processReply(Ptr<Node> thisNode, uint32_t sourceId,int sendNum,uint32_t gatewayId);
    void generateCache(Ptr<Node> thisNode,uint32_t sourceId,int sendNum,uint32_t sendTime);
    bool IsVerticalRegion(Ptr<Node> thisNode);
    double GetdistanFromMSink(Ptr<Node> srcN);
    double calculate(Ptr<Node>thisNode, uint32_t id);
    bool IsVerticalRegion(double posx1, double posy1, double posx2, double posy2);
    void SendReplyTransPacket(Ptr<Node>fromnode, Ptr<Node>tonode, int sendNum,uint32_t sourceId);
    bool isExist(Ptr<Node> thisNode,uint32_t sendNum);
    uint32_t AnalyzeDataPacket(stringstream& ss, int& sendNum, uint32_t& sendTime);
    uint32_t AnalyzeReplyPacket(stringstream& ss, int& sendNum, uint32_t& nodeId);
    double getNeighLocInput(Ptr<Node>thisNode, uint32_t id);
    double getNeighZInput(Ptr<Node>thisNode, uint32_t id);
    void getNeighNum();
    double getNeighVelocityInput(Ptr<Node>thisNode,uint32_t id);
    int32_t ProcessDataPacket(Ptr<Node> thisNode, Ptr<Packet> packet,Ipv4Header h);
    double GetdistanOf2Nodes(Vector one,Vector two);
    double GetdistanOf2Id(uint32_t id1,uint32_t id2);
	
}
#endif