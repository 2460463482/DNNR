#include "final_record.h"
#include <string>
#include <iomanip>
#include "ns3/mobility-module.h"
#include "final_record.h"
#include "global.h"

using namespace std;
using namespace ns3;

extern NodeContainer senseNodes;
extern NodeContainer mobileSinkNode; 
extern nodestate NS[201];
extern vector<double>delay;
extern double netDelay;
extern vector <int> validJumps;
extern double para3D;
extern uint32_t receivepacket;
extern int maxPackets;
extern double initialJ;
extern uint32_t nNodes;
extern int inputSpeed;
extern int moveSpeed;
extern int netSizeXY;
extern int netSizeZ;
extern int send;
extern double caculateTime;
extern int countnum;
extern int JumpsArry[6000];

namespace ns3 {
NS_LOG_COMPONENT_DEFINE("TYPEMSG");

//-------------------------------------------------------------------------------------
void finalRecord(){
	double energySum=0;
	for (NodeContainer::Iterator itr = senseNodes.Begin(); itr != senseNodes.End(); itr++) {
		uint32_t id = (*itr)->GetId();
		energySum+=NS[id].remainingJ;
	}
	std::stringstream ss;
    ss << "/home/wsn/sim_temp/DNNR/DNNR"<<moveSpeed<<"-"<<inputSpeed<<"-"<<netSizeXY<<"-"<<netSizeZ<<"-"<<nNodes<<"-"<<maxPackets<<".record";
	uint32_t delaySum = 0;
	for (uint32_t i = 0; i < delay.size(); i++) {
		delaySum += delay[i];
	}
	cout<<" delay.size():"<< delay.size()<<endl;
	netDelay = delaySum / delay.size();
	std::ofstream of(ss.str().c_str());
	double jumpAve = 0;
	for (uint32_t i = 0; i < validJumps.size(); i++) {
		jumpAve += validJumps[i];
	}
	jumpAve = jumpAve / validJumps.size();
	for (uint32_t i = 0; i < validJumps.size(); i++) {
		para3D += (JumpsArry[i] - jumpAve)* (JumpsArry[i] - jumpAve);
	}
	para3D = para3D / validJumps.size();
	cout << "Path scalability" << jumpAve << " " << para3D << " " << send << endl;
	
	std::cout << "Delay: " << netDelay/1000<<endl;
	std::cout<<"PDR:"<< receivepacket*1.0/maxPackets*100<<"%"<<endl;
	std::cout<<"network throughput："<< receivepacket*1024/(Simulator::Now().GetSeconds())*8/1000<<"(kbps)"<<endl;
	std::cout<<"Total energy consumption："<<(initialJ*nNodes-energySum)/1000000000<<endl;
	std::cout<<"Energy consumption / number of successful packets："<<(((initialJ*nNodes-energySum)/1000000000)*(100- (receivepacket * 1.0 / maxPackets * 100)))/(receivepacket * 1.0 / maxPackets * 100)<<endl;

	ss << std::endl << "Delay:" << netDelay/1000<<"(ms)"<< std::endl;
	ss << std::endl<<"network throughput："<< receivepacket * 1024 / (Simulator::Now().GetSeconds()) * 8 / 1000 << "(kbps)" <<endl;
	ss << std::endl << "PDR:" << receivepacket*1.0 / maxPackets *100<<"%"<<endl;
	ss << "Path scalability" << jumpAve << " " << para3D << " " << send << endl;
	ss << "Total energy consumption："<<(initialJ*nNodes-energySum)/1000000000<<endl;
	ss << "Energy consumption / number of successful packets："<<(((initialJ*nNodes-energySum)/1000000000)*(100- (receivepacket * 1.0 / maxPackets * 100)))/(receivepacket * 1.0 / maxPackets * 100)<<endl;
	ss << "caculateTime " << caculateTime/1000<< " countnum " << countnum<<endl;
	NS_LOG_INFO(ss.str().c_str());
	of << ss.str().c_str();
	of.close();
}

}
