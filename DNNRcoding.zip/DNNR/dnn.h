#ifndef _DNN_H  
#define _DNN_H  
#include<stdio.h>  
#include<math.h>  
#include <stdlib.h>  
#include <time.h>  
#define DNN_VEC 8  
#define DNN_INUM 8  

//-------------------------------------------------------------------------------------
double dnn_sig(double in) {   
	return 1.0 / (1.0 + exp(-1.0 * in));
}

//-------------------------------------------------------------------------------------
struct dnn_cell { 
	double w[DNN_INUM];
	double wb;
	double in[DNN_INUM];
	double out;
	double error;
	double v;
	void SetCell_Default() {  
		int i;
		for (i = 0; i < DNN_INUM; i++) {
			w[i] = 0.000001;
		}
		wb = 0.000001;
		v = 0.001;
	}
	void SetCell_InitWeight(double Initial) { 
		int i;
		for (i = 0; i < DNN_INUM; i++) {
			w[i] = Initial;
		}
		wb = Initial;
		v = 0.001;
	}
	void SetCell_InitAll(double Initial, double InV) {
		int i;
		for (i = 0; i < DNN_INUM; i++) {
			w[i] = Initial;
		}
		wb = Initial;
		v = InV;
	}
	void SetCell_Precise(double* InW, double InWb, double InV) {
		int i;
		for (i = 0; i < DNN_INUM; i++) {
			w[i] = InW[i];
		}
		wb = InWb;
		v = InV;
	}
	void SetIn(double* SIn) {
		int i;
		for (i = 0; i < DNN_INUM; i++) {
			in[i] = SIn[i];
		}
	}
	double GetOut() { 
		int i;
		double sum = 0;
		for (i = 0; i < DNN_INUM; i++) {
			sum += w[i] * in[i];
		}
		sum += wb;
		out = dnn_sig(sum);
		return out;
	}
	void UpdateWeight() { 
		int i;
		for (i = 0; i < DNN_INUM; i++) {
			w[i] -= v * error * out * (1 - out) * in[i];
		}
		wb = v * error * out * (1 - out);
	}
	void SetError(double InErr) {
		error = InErr;
	}
	void SetSpeed(double InV) { 
		v = InV;
	}
};

//-------------------------------------------------------------------------------------
double DNN_Cal(dnn_cell* incell, int deep, double* in)
{
	double out = 0;
	int  i, j, k, count = 0;
	double tmp[DNN_INUM];
	for (i = 0; i < DNN_INUM; i++)  tmp[i] = in[i];
	for (j = 0; j < deep - 1; j++)
	{
		for (i = j * DNN_INUM; i < (j * DNN_INUM + DNN_INUM); i++)
		{
			incell[i].SetIn(tmp);
			incell[i].GetOut();
			count++;
		}
		k = 0;
		for (i = j * DNN_INUM; i < (j * DNN_INUM + DNN_INUM); i++) { tmp[k] = incell[i].out; k++; }
	}
	incell[count].SetIn(tmp);
	out = incell[count].GetOut();
	return out;
}

//-------------------------------------------------------------------------------------
double DNN_Train(dnn_cell* cell, int deep, double InMat[DNN_VEC][DNN_INUM], double* expect, int n)
{
	double out, devi, sum;
	double de[DNN_VEC];
	int co = n, kp = -1;
	int i, j, k, tt, l;
	for (i = 0; i < DNN_VEC; i++) de[i] = 9.9;
	while (co--) {
		kp = (int)(rand() * (double)(DNN_VEC) / RAND_MAX);
		out = DNN_Cal(cell, deep, InMat[kp]);
		devi = out - expect[kp];
		de[kp] = devi;
		tt = (deep - 1) * DNN_INUM;
		cell[tt].error = devi;
		l = 0;
		for (i = (deep - 2) * DNN_INUM; i < tt; i++) { cell[i].error = cell[tt].error * cell[tt].out * (1 - cell[tt].out) * cell[tt].w[l]; l++; }
		for (j = deep - 2; j > 0; j--) {
			l = 0;
			for (i = (j - 1) * DNN_INUM; i < j * DNN_INUM; i++) {
				sum = 0;
				for (k = j * DNN_INUM; k < (j + 1) * DNN_INUM; k++) {
					sum += cell[k].error * cell[k].out * (1 - cell[k].out) * cell[k].w[l];
				}
				cell[i].error = sum;
				l++;
			}
		}
		for (i = 0; i <= (deep - 1) * DNN_INUM; i++) {
			cell[i].UpdateWeight();
		}
		for (i = 0; i <= (deep - 1) * DNN_INUM; i++) {
			cell[i].SetSpeed(fabs(devi));
		}
	}
	sum = 0;
	for (i = 0; i < DNN_VEC; i++) sum += fabs(de[i]);
	return sum / DNN_VEC;
}
#endif  