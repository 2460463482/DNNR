#include "ns3/node-container.h"
#include <iomanip>
#include "ns3/mobility-module.h"
#include <map>
#include <vector>
#include "math.h"
#include "BSBroadcast.h"
#include "global.h"
using namespace std;
using namespace ns3;
extern uint32_t nNodes;
extern nodestate NS[201];
extern double buildNeighborDone ;
extern double updateInterval ;
extern int BSRoundNum;
extern double totalConsumed;
extern double Node_Vx[201];
extern double Node_Vy[201];
extern double Node_Vz[201];
extern double Node_Lx[201];
extern double Node_Ly[201];
extern double Node_Lz[201];
extern int Node_level[201];
extern uint32_t transTime[201];
extern uint32_t transTime1[201];
extern double node_delay[201][201];
extern bool reliableArea[201][201];
extern uint32_t BSSendTime;
extern bool updateDone ;
static TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
static InetSocketAddress broadcastAdr = InetSocketAddress(Ipv4Address::GetBroadcast(), 80);
extern NodeContainer senseNodes;
extern NodeContainer mobileSinkNode; 
#define level_height 30
namespace ns3 {
	NS_LOG_COMPONENT_DEFINE("BSBroadcast");

	//-------------------------------------------------------------------------------------
	void BsBroadcast(Ptr<Node> BSnode) {
		NS[200].RecvBSBroadcast = true;
		NS[200].isSignNode = true;
		NS[200].NodeLevel = 0;
		BSRoundNum= BSRoundNum+1;
		Ipv4Address BroadcastSource = GetNodeIpv4Address(BSnode);
		stringstream ss;
		uint32_t BS_SendTime = Simulator::Now().GetMicroSeconds();
		BSSendTime=BS_SendTime;
		Vector BS_Position = BSnode->GetObject<MobilityModel>()->GetPosition();
		Vector BS_Velocity = BSnode->GetObject<MobilityModel>()->GetVelocity();
		ss << BS_SendTime << "/" << BS_Position.x << "/" << BS_Position.y << "/" << BS_Position.z<<"/"<< BS_Velocity.x << "/" << BS_Velocity.y<<"/"<< BS_Velocity.z;
		stringstream pktContents(ss.str().c_str());
		Ptr<Packet> pkt = Create<Packet>((uint8_t*)pktContents.str().c_str(), pktContents.str().length());
		Ipv4Header ipv4Header;
		pktType pktType = BS_Location_Type;
		ipv4Header.SetSource(BroadcastSource);
		ipv4Header.SetIdentification(pktType);
		pkt->AddHeader(ipv4Header);
		Ptr<Socket> source = Socket::CreateSocket(BSnode, tid);
		source->Connect(broadcastAdr);
		source->SetAllowBroadcast(true);
		source->Send(pkt); 
	}

	
	//-------------------------------------------------------------------------------------
	int32_t ProcessLocationPacket(Ptr<Node> ReceivedBSLocationNode, Ptr<Packet> BS_LocationPacket) {
		stringstream recvData;
		BS_LocationPacket->CopyData(&recvData, BS_LocationPacket->GetSize());
		Vector BS_Location;
		Vector BS_Velocity;
		uint32_t BS_SendTime = AnalyzeBSLocationPacket(recvData, BS_Location, BS_Velocity);
		double interval = RandomDoubleVauleGenerator(0.0, 0.1);
		if(IsVerticalRegion(ReceivedBSLocationNode, BS_Location.x, BS_Location.y)){
			NS[ReceivedBSLocationNode->GetId()].BS_SendTime = BS_SendTime;
			NS[ReceivedBSLocationNode->GetId()].BS_PositionX = BS_Location.x;
			NS[ReceivedBSLocationNode->GetId()].BS_PositionY = BS_Location.y;
			NS[ReceivedBSLocationNode->GetId()].BS_PositionZ = BS_Location.z;
			NS[ReceivedBSLocationNode->GetId()].BS_VelocityX = BS_Velocity.x;
			NS[ReceivedBSLocationNode->GetId()].BS_VelocityY = BS_Velocity.y;
			NS[ReceivedBSLocationNode->GetId()].BS_VelocityZ = BS_Velocity.z;
			NS[ReceivedBSLocationNode->GetId()].RecvBSBroadcast = true;
			NS[ReceivedBSLocationNode->GetId()].isSignNode = true;
			NS[ReceivedBSLocationNode->GetId()].NodeLevel = 1;
			Node_level[ReceivedBSLocationNode->GetId()]=1;
			if (NS[ReceivedBSLocationNode->GetId()].BSNum!= BSRoundNum) {
				NS[ReceivedBSLocationNode->GetId()].BSNum = BSRoundNum;
				Simulator::Schedule(Seconds(interval), &ContinueBSLocationBroadcast, ReceivedBSLocationNode, BS_SendTime, BS_Location, BS_Velocity);
			}
		}
		return 0;
	}


	//-------------------------------------------------------------------------------------
	uint32_t AnalyzeBSLocationPacket(stringstream& ss, Vector& BS_Location, Vector& BS_Velocity) {
		uint32_t BS_SendTime;
		stringstream si;
		char c[ss.str().size()];
		ss >> c;
		char* p = c;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_SendTime;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Location.x;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Location.y;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Location.z;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Velocity.x;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Velocity.y;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Velocity.z;
		return BS_SendTime;
	}

	//-------------------------------------------------------------------------------------
	 uint32_t AnalyzeLocationPacket(stringstream& ss, Vector& BS_Location, Vector& BS_Velocity, uint32_t& id) {
		uint32_t BS_SendTime;
		stringstream si;
		char c[ss.str().size()];
		ss >> c;
		char* p = c;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> id;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Location.x;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Location.y;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Location.z;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Velocity.x;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Velocity.y;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_Velocity.z;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> BS_SendTime;
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> transTime1[id];
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> Node_Lx[id];
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> Node_Ly[id];
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> Node_Lz[id];
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> Node_Vx[id];
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> Node_Vy[id];
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> Node_Vz[id];
		si.str("");
		si.clear();
		p++;
		while (*p != '/') {
			si << *p;
			p++;
		}
		si >> Node_level[id];
		si.str("");
		si.clear();
		return BS_SendTime;
	}

	//-------------------------------------------------------------------------------------
	void ContinueBSLocationBroadcast(Ptr<Node> ReceivedBSLocationNode, uint32_t BS_SendTime, Vector BS_Location, Vector BS_Velocity) {
		Ipv4Address sinkSource = GetNodeIpv4Address(ReceivedBSLocationNode);
		stringstream ss;
		ss << BS_SendTime << "/" << BS_Location.x << "/" << BS_Location.y << "/" << BS_Location.z << "/" << BS_Velocity.x << "/" << BS_Velocity.y << "/" << BS_Velocity.z  ;
		stringstream pktContents(ss.str().c_str());
		Ptr<Packet> pkt = Create<Packet>((uint8_t*)pktContents.str().c_str(), pktContents.str().length());
		Ipv4Header ipv4Header;
		pktType pktType = BS_Location_Type;
		ipv4Header.SetSource(sinkSource);
		ipv4Header.SetIdentification(pktType);
		pkt->AddHeader(ipv4Header);
		Ptr<Socket> source = Socket::CreateSocket(ReceivedBSLocationNode, tid);
		source->Connect(broadcastAdr);
		source->SetAllowBroadcast(true);
		source->Send(pkt);
		uint32_t thispktsize = 100;
		uint32_t idf = ReceivedBSLocationNode->GetId();
		double oldValuef = NS[idf].remainingJ;
		double consumedJf;
		consumedJf = 50 * 0.000000001 * 1e9 * thispktsize;
		if (oldValuef > consumedJf) {
			NS[idf].remainingJ -= consumedJf;
			totalConsumed = totalConsumed + consumedJf;
		}
		else {
			NS[idf].isdead = true;
			NS[idf].remainingJ = 0;
		}
	}

	//-------------------------------------------------------------------------------------
	int32_t ProcessNodePacket(Ptr<Node> ReceivedBSLocationNode, Ptr<Node> srcNode, Ptr<Packet> BS_LocationPacket) {
		stringstream recvData;
		BS_LocationPacket->CopyData(&recvData, BS_LocationPacket->GetSize());
		Vector BS_Location;
		Vector BS_Velocity;
		uint32_t a = 0;
		uint32_t BS_SendTime = AnalyzeLocationPacket(recvData, BS_Location, BS_Velocity,a);
		uint32_t recv_Time = Simulator::Now().GetMicroSeconds();
		int neiId = a;
		node_delay[neiId][ReceivedBSLocationNode->GetId()]=recv_Time-transTime[neiId];
		NS[ReceivedBSLocationNode->GetId()].BS_SendTime = BS_SendTime;
		NS[ReceivedBSLocationNode->GetId()].BS_PositionX = BS_Location.x;
		NS[ReceivedBSLocationNode->GetId()].BS_PositionY = BS_Location.y;
		NS[ReceivedBSLocationNode->GetId()].BS_PositionZ = BS_Location.z;
		NS[ReceivedBSLocationNode->GetId()].BS_VelocityX = BS_Velocity.x;
		NS[ReceivedBSLocationNode->GetId()].BS_VelocityY = BS_Velocity.y;
		NS[ReceivedBSLocationNode->GetId()].BS_VelocityZ = BS_Velocity.z;
		NS[ReceivedBSLocationNode->GetId()].RecvBSBroadcast = true;
		if(NS[ReceivedBSLocationNode->GetId()].NodeLevel==0 && ReceivedBSLocationNode->GetId()!=200){
			NS[ReceivedBSLocationNode->GetId()].NodeLevel = Node_level[neiId] + 1;
			Node_level[ReceivedBSLocationNode->GetId()]=NS[ReceivedBSLocationNode->GetId()].NodeLevel;
		}
		else if (NS[ReceivedBSLocationNode->GetId()].NodeLevel > Node_level[neiId]) {
			NS[ReceivedBSLocationNode->GetId()].NodeLevel = Node_level[neiId] + 1;
			Node_level[ReceivedBSLocationNode->GetId()]=NS[ReceivedBSLocationNode->GetId()].NodeLevel;
		}
		Vector receivedNode_position = ReceivedBSLocationNode->GetObject<MobilityModel>()->GetPosition();
		bool flag = Grading(receivedNode_position.z,Node_Lz[neiId]);
		reliableArea[srcNode->GetId()][ReceivedBSLocationNode->GetId()]=flag;
		double interval = RandomDoubleVauleGenerator(0.0, 0.1);
		if (NS[ReceivedBSLocationNode->GetId()].BSNum != BSRoundNum) {
			NS[ReceivedBSLocationNode->GetId()].BSNum = BSRoundNum;
			Simulator::Schedule(Seconds(interval), &ContinueNodeBroadcast, ReceivedBSLocationNode, BS_SendTime, BS_Location, BS_Velocity);
		}
		return 0;
	}
	
	//-------------------------------------------------------------------------------------
	void ContinueNodeBroadcast(Ptr<Node> ReceivedBSLocationNode, uint32_t BS_SendTime, Vector BS_Location, Vector BS_Velocity) {
		Ipv4Address sinkSource = GetNodeIpv4Address(ReceivedBSLocationNode);
		Vector location = ReceivedBSLocationNode->GetObject<MobilityModel>()->GetPosition();
		Vector velocity = ReceivedBSLocationNode->GetObject<MobilityModel>()->GetVelocity();
		uint32_t Node_SendTime = Simulator::Now().GetMicroSeconds();
		uint32_t Node_Id = ReceivedBSLocationNode->GetId();
		transTime[Node_Id] = Simulator::Now().GetMicroSeconds();
		Node_Lx[Node_Id]=location.x;
		Node_Ly[Node_Id]=location.y;
		Node_Lz[Node_Id]=location.z;
		Node_Vx[Node_Id]=velocity.x;
		Node_Vy[Node_Id]=velocity.y;
		Node_Vz[Node_Id]=velocity.z;
		stringstream ss;
		ss << Node_Id << "/" << BS_Location.x << "/" << BS_Location.y << "/" << BS_Location.z << "/" << BS_Velocity.x << "/" << BS_Velocity.y << "/" << BS_Velocity.z << "/";
		ss << BS_SendTime << "/" << Node_SendTime << "/" << location.x << "/" << location.y << "/" << location.z << "/" << velocity.x << "/" << velocity.y << "/" << velocity.z<<"/"<<NS[Node_Id].NodeLevel;
		stringstream pktContents(ss.str().c_str());
		Ptr<Packet> pkt = Create<Packet>((uint8_t*)pktContents.str().c_str(), pktContents.str().length());
		Ipv4Header ipv4Header;
		pktType pktType = REQ_Type;
		ipv4Header.SetSource(sinkSource);
		ipv4Header.SetIdentification(pktType);
		pkt->AddHeader(ipv4Header);
		Ptr<Socket> source = Socket::CreateSocket(ReceivedBSLocationNode, tid);
		source->Connect(broadcastAdr);
		source->SetAllowBroadcast(true);
		source->Send(pkt);
		uint32_t idf = ReceivedBSLocationNode->GetId();
		double oldValuef = NS[idf].remainingJ;
		double consumedJf;
		consumedJf = 50 * 0.000000001 * 1e9 * 100 ;
		if (oldValuef > consumedJf) {
			NS[idf].remainingJ -= consumedJf;
			totalConsumed = totalConsumed + consumedJf;
		}
		else {
			NS[idf].isdead = true;
			NS[idf].remainingJ = 0;
		}
	}


	//-------------------------------------------------------------------------------------
	void startRoute(Ptr<Node>thisNode, Ipv4Address srcAdr) {
		uint32_t transtime;
		transtime = Simulator::Now().GetMicroSeconds();
		Vector location = thisNode->GetObject<MobilityModel>()->GetPosition();
		Vector velocity = thisNode->GetObject<MobilityModel>()->GetVelocity();
		stringstream ssData;
		uint32_t node_Id = thisNode->GetId();
		transTime[node_Id] = transtime;
		Node_Lx[node_Id]=location.x;
		Node_Ly[node_Id]=location.y;
		Node_Lz[node_Id]=location.z;
		Node_Vx[node_Id]=velocity.x;
		Node_Vy[node_Id]=velocity.y;
		Node_Vz[node_Id]=velocity.z;
		ssData << node_Id << "/" << NS[node_Id].BS_PositionX << "/" << NS[node_Id].BS_PositionY << "/" << NS[node_Id].BS_PositionZ << "/" << NS[node_Id].BS_VelocityX << "/" << NS[node_Id].BS_VelocityY << "/" << NS[node_Id].BS_VelocityZ << "/";
		ssData << NS[node_Id].BS_SendTime << "/" << transTime << "/" << location.x << "/" << location.y << "/" << location.z << "/" << velocity.x << "/" << velocity.y << "/" << velocity.z << "/" << NS[node_Id].NodeLevel;
		stringstream REQss(ssData.str().c_str());
		Ptr<Packet> pkt = Create<Packet>((uint8_t*)REQss.str().c_str(), REQss.str().length());
		Ipv4Header ipv4Header;
		pktType pktType = REQ_Type;
		ipv4Header.SetSource(srcAdr);
		ipv4Header.SetIdentification(pktType);
		pkt->AddHeader(ipv4Header);
		Ptr<Socket> source = Socket::CreateSocket(thisNode, tid);
		source->Connect(broadcastAdr);
		source->SetAllowBroadcast(true);
		source->Send(pkt);
	}

	//-------------------------------------------------------------------------------------
	void updateNeighbor() {
		double interval = 0;
		for (NodeContainer::Iterator i = senseNodes.Begin(); i != senseNodes.End();
			i++) {
			Ptr<Node> thisNode = *i;
			if (NS[thisNode->GetId()].isSignNode) {
				Ipv4Address srcAdr = GetNodeIpv4Address(thisNode);
				Simulator::Schedule(Seconds(interval), &startRoute, thisNode, srcAdr);
				interval = interval+0.03;
			}
		}
	}

	//-------------------------------------------------------------------------------------
	void setUpdateDoneFlag(bool flag) {
		updateDone = flag;
	}
	
	//-------------------------------------------------------------------------------------
	bool IsVerticalRegion(Ptr<Node> thisNode,double posx,double posy) {
		Vector one;
		one = thisNode->GetObject<MobilityModel>()->GetPosition();
		double dis = std::pow((one.x - posx) * (one.x - posx) + (one.y - posy) * (one.y - posy), 1.0 / 2);
		if (dis < cylinderR)
			return true;
		else
			return false;
	}

	//-------------------------------------------------------------------------------------
	bool Grading(double Lz1, double Lz2) {
		if(fabs(Lz1-Lz2) <= level_height){
			return true;
		}else{
			return false;
		}
	}
}