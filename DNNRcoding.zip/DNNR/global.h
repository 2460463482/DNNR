#ifndef GLOBAL_H
#define GLOBAL_H

#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include <fstream>
#include <vector>
using namespace std;

namespace ns3 {
	#define TIME_STAMP Simulator::Now().GetSeconds()<<": "
	#define TIME_STAMP_FUC Simulator::Now().GetSeconds()<<": ("<<__FUNCTION__<<") "
	#define FUC __FUNCTION__<<": "
	#define MAX_NUM 201

	enum nodeType {
		sense_Type = 0,
		sink_Type = 1,
		mobileSink_Type = 2,
		relay_Type = 3,
	} ;

	enum pktType {
		data_Type = 1, spt_Type = 2, sinkCheck_Type = 3, 
		dataGathering_Type = 4,drainNotice_Type=5,relayCheck_Type = 6,REQ_Type = 7,
		BS_Location_Type = 8, Reply_Trans_Type=9,
	};

	struct dataCache {
		uint32_t sourceId;
		int sendNum;
		uint32_t sendTime;
		bool isSend;
		bool isReceReply;
		uint32_t attempts;
	};
	struct nodestate {
		bool RecvBSBroadcast;
		double BS_PositionX;
		double BS_PositionY;
		double BS_PositionZ;
		double BS_VelocityX;
		double BS_VelocityY;
		double BS_VelocityZ;
		uint32_t BS_SendTime;
		double remainingJ;
		bool isSignNode;
		bool isdead;
		int BSNum;
		int NodeLevel;
		vector<dataCache> nodeCache;
	};

	enum nodeType isSinkType(Ptr<Node> node, Ptr<Node> mobilenode);
	enum nodeType CheckNodeType(Ptr<Node> node,NodeContainer senseNodes,Ptr<Node> mobilenode);
	Ptr<Node> GetNodePtrFromGlobalId(uint32_t id, NodeContainer n,NodeContainer mobileSinkNode);	
	double RandomDoubleVauleGenerator(double min, double max);
	Ipv4Address GetNodeIpv4Address(Ptr<Node> n);
	Ptr<Node> GetNodePtrFromIpv4Adr(Ipv4Address adr,NodeContainer senseNodes,NodeContainer mobileSinkNode);
	void FindInrangeNodes(NodeContainer allNodes);
	inline double GetDistanceOf2Nodes(Ptr<Node> srcN, Ptr<Node> remN);
}

#endif
