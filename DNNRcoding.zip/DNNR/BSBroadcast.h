#ifndef BSBROADCAST_H
#define BSBROADCAST_H
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/network-module.h"
#include "ns3/node-container.h"
#include <iomanip>
#include <fstream>
using namespace std;
namespace ns3 {
#define cylinderR 225
	void BsBroadcast(Ptr<Node> BSnode);
	bool Grading(double Lz1, double Lz2);
	int32_t ProcessLocationPacket(Ptr<Node> ReceivedBSLocationNode, Ptr<Packet> BS_LocationPacket);
	uint32_t AnalyzeBSLocationPacket(stringstream& ss, Vector& BS_Location, Vector& BS_Velocity);
	uint32_t AnalyzeLocationPacket(stringstream &ss, Vector &BS_Location, Vector &BS_Velocity,uint32_t& id);
	void ContinueBSLocationBroadcast(Ptr<Node> ReceivedBSLocationNode, uint32_t BS_SendTime, Vector BS_Location, Vector BS_Velocity);
	void ContinueNodeBroadcast(Ptr<Node> ReceivedBSLocationNode, uint32_t BS_SendTime, Vector BS_Location, Vector BS_Velocity);
	int32_t ProcessNodePacket(Ptr<Node> ReceivedBSLocationNode, Ptr<Node> srcNode, Ptr<Packet> BS_LocationPacket);
	void setUpdateDoneFlag(bool flag);
	void startRoute(Ptr<Node>thisNode, Ipv4Address srcAdr);
	void updateNeighbor();
	bool IsVerticalRegion(Ptr<Node> thisNode,double posx,double posy);
}
#endif