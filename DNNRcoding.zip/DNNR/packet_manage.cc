#include "ns3/node-container.h"
#include <iomanip>
#include "ns3/mobility-module.h"
#include "global.h"
#include <map>
#include <vector>
#include<string>

#include "math.h"
#include "time.h"
#include "stdlib.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <map>
#include <stack>
#include <string>
#include <iomanip>
#include <fann/fann.h>
#include <cmath>


#include "packet_manage.h"


using namespace ns3;
using namespace std;

double ETX= 50 * 0.000000001 * 1e9;
double ERX= 50 * 0.000000001 * 1e9;
double Efs = 10 * 0.000000000001 * 1e9;
double Emp = 0.0013 * 0.000000000001 * 1e9;
double d0 = sqrt(Efs / Emp);

int tranFail=0;
int noReplyFail=0;
int send2BSFail=0;
int deleteInvalidCacheTimes=0;
int disFail=0;
int transTimes=0;
int cacheTimes=0;
int deleteNeighFail=0;

extern int transState[201][201];
extern double caculateTime;
extern int countnum;
extern bool isRetry[5001];
extern vector<vector<double> >recvRatio;

double waitReplyTime=0.05;
double validTime=8.0;

extern clock_t lifeTime;
extern double maxDis;
extern int maxPackets;
extern uint32_t pktSize;
extern double totalBytesGenerated;
extern double totalConsumed;
extern nodestate NS[201];
extern int moveSpeed;
extern struct fann* ann;
extern bool isStatic;

int old_NeighNum[201];
int new_NeighNum[201];
extern double Node_Vx[201];
extern double Node_Vy[201];
extern double Node_Vz[201];
extern double Node_Lx[201];
extern double Node_Ly[201];
extern double Node_Lz[201];
extern int Node_level[201];
extern uint32_t transTime[201];
extern uint32_t transTime1[201];
extern double node_delay[201][201];
extern bool reliableArea[201][201];
extern uint32_t BSSendTime;
extern bool updateDone ;
static TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
static InetSocketAddress broadcastAdr = InetSocketAddress(Ipv4Address::GetBroadcast(), 80);
extern NodeContainer senseNodes;
extern NodeContainer mobileSinkNode; 

extern GraphList graph;
extern int send;
extern map<uint32_t,Ipv4Address>mapIdAdr;

namespace ns3 {
NS_LOG_COMPONENT_DEFINE("PACKET_MANAGE");

//-------------------------------------------------------------------------------------
void TransmitDataPacket(Ptr<Node> localNode, Ipv4Address sourceAdr,
		Ipv4Address sinkAdr,int sendNum, uint32_t Node_SendTime) {
	NS_LOG_LOGIC(
			std::endl<<TIME_STAMP_FUC <<sourceAdr <<" to "<<sinkAdr<<" by "
			<<GetNodeIpv4Address(localNode));
	if (CheckRemainingJ(localNode)) {
		transTimes++;
		Ipv4Address localAdr = GetNodeIpv4Address(localNode);
		uint32_t localId = localNode->GetId();
		uint32_t gatewayId = 1024;
		bool flag = false;
		double weight1 = 1024;
		double weight3 = 0;
		double weight4 = 0;
		int minId1 = 1024;
		int minId2 = 1024;
		int minId3 = 1024;
		int minId4 = 1024;
		for (int i = 0; i < graph.m_vCount; ++i){
			int curId = graph.m_vVertex[i].id;
			if((uint32_t)curId != localId)
				continue;
			Edge* edge = graph.m_vVertex[i].next;
			while (edge) {
				double	distance1, distance2, distance3;
				uint32_t  t = Simulator::Now().GetMicroSeconds();
				Vector location = localNode->GetObject<MobilityModel>()->GetPosition();
				double BS_Lx = NS[localNode->GetId()].BS_PositionX + (double)(t - BSSendTime) *  NS[localNode->GetId()].BS_VelocityX * 0.000001;
				double BS_Ly = NS[localNode->GetId()].BS_PositionY + (double)(t - BSSendTime) *  NS[localNode->GetId()].BS_VelocityY * 0.000001;
				double BS_Lz = NS[localNode->GetId()].BS_PositionZ + (double)(t - BSSendTime) *  NS[localNode->GetId()].BS_VelocityZ * 0.000001;
				distance2 = std::sqrt((BS_Lx- location.x)* (BS_Lx - location.x) + (BS_Ly - location.y) * (BS_Ly - location.y) + (BS_Lz - location.z) * (BS_Lz - location.z));
				double N_Lx = Node_Lx[edge->id] + (double)(t - transTime[edge->id]) * Node_Vx[edge->id] * 0.000001;
				double N_Ly = Node_Ly[edge->id] + (double)(t - transTime[edge->id]) * Node_Vy[edge->id] * 0.000001;
				double N_Lz= Node_Lz[edge->id] + (double)(t - transTime[edge->id]) * Node_Vz[edge->id] * 0.000001;
				distance3 = std::sqrt((N_Lx- location.x)* (N_Lx - location.x) + (N_Ly - location.y) * (N_Ly - location.y) + (N_Lz - location.z) * (N_Lz - location.z));
				double distance4= std::sqrt((N_Lx - BS_Lx) * (N_Lx - BS_Lx) + (N_Ly - BS_Ly) * (N_Ly - BS_Ly) + (N_Lz - BS_Lz) * (N_Lz - BS_Lz));
				Ptr<Node>nodePtr = GetNodePtrFromGlobalId(edge->id,senseNodes,mobileSinkNode);
				bool isSign = IsVerticalRegion(N_Lx,N_Ly,BS_Lx,BS_Ly);
				bool isReliable=false;
				if (edge->id == 200) {
					distance1 = distance2;
					if (fabs(BS_Lz - location.z) < 50) isReliable = true;
				}
				else {
					distance1 = distance3;
					if (fabs(N_Lz - location.z) < 50) isReliable = true;
				}
				if (distance1<=maxDis) {
					if (edge->id == 200) {
						gatewayId = 200;
						flag = true;
					}
					else if (isSign) {
						double weight = distance4;
						if (weight < weight1) {
							weight1 = weight;
							minId1 = (uint32_t)edge->id;
						}
					}
					else if (isReliable) {
						double weight = calculate(localNode, edge->id); 
						if (weight > weight3) {
							weight3 = weight;
							minId3 = (uint32_t)edge->id;
						}
					}
					else {
						double weight = calculate(localNode, edge->id);
						if (weight >weight4) {
							weight4 = weight;
							minId4 = (uint32_t)edge->id;
						}
					}
					flag = true;
				}
				edge = edge->next;
			}
			if (gatewayId != 200) {
				if (minId1 != 1024) {
					gatewayId = minId1;
				}
				else if (minId2 != 1024) {
					gatewayId = minId2;
				}
				else if (minId3 != 1024) {
					gatewayId = minId3;
				}
				else {
					gatewayId = minId4;
				}
				if (!flag) {
					gatewayId = 1024;
				}
			}
			break;
		}
		if(gatewayId == 1024){
			tranFail++;
			vector<dataCache>::iterator it;
			for(it=NS[localNode->GetId()].nodeCache.begin();it!=NS[localNode->GetId()].nodeCache.end();){
        		if(it->sourceId==GetNodePtrFromIpv4Adr(sourceAdr,senseNodes,mobileSinkNode)->GetId()&&it->sendNum==sendNum){
					it->isSend=false;
					break;
				}
				else
					it++;
			}
			return;
		}

		pktType pktType = data_Type;
		Ipv4Address gatewayAdr = mapIdAdr[gatewayId];
		Ptr<Node>nodePtr = GetNodePtrFromGlobalId(gatewayId,senseNodes,mobileSinkNode);
		Vector fromLocation = localNode->GetObject<MobilityModel>()->GetPosition();
		Vector toLocation = nodePtr->GetObject<MobilityModel>()->GetPosition();
		double distance2node=GetdistanOf2Nodes(fromLocation,toLocation);
		if(distance2node>maxDis)
			disFail++;
		NS_LOG_LOGIC(
				TIME_STAMP_FUC<<"localAdr = "<<localAdr <<", sinkAdr = "<<sinkAdr<<", gatewayAdr = "<<gatewayAdr);
		stringstream ss;
		uint32_t nodeID = localNode->GetId();
		ss << sendNum << "/" << Node_SendTime << "/"<<nodeID<<"/";
		stringstream pktContents(ss.str().c_str());
		Ptr<Packet> dataPkt = Create<Packet>((uint8_t*)pktContents.str().c_str(), pktContents.str().length());
		Ipv4Header h;
		h.SetDestination(sinkAdr);
		h.SetSource(sourceAdr);
		h.SetIdentification(pktType);
		dataPkt->AddHeader(h);
		InetSocketAddress gateAdr = InetSocketAddress(gatewayAdr, 80);
		Ptr<Socket> srcSoc = Socket::CreateSocket(localNode, tid);
		srcSoc->Connect(gateAdr);
		srcSoc->Send(dataPkt);
		uint32_t idf = localNode->GetId();
		double oldValuef = NS[idf].remainingJ;
		uint32_t thisPktSize = 1024;
		double consumedJf;
		if (distance2node >= d0)
			consumedJf = ETX * thisPktSize + Emp * thisPktSize * (pow(distance2node, 4));
		else
			consumedJf = ETX * thisPktSize + Efs * thisPktSize * (pow(distance2node, 2));
		if (oldValuef > consumedJf) {
			NS[idf].remainingJ -= consumedJf;
			totalConsumed = totalConsumed + consumedJf;
		}
		else {
			NS[idf].isdead = true;
			NS[idf].remainingJ = 0;
		}
		Simulator::Schedule(Seconds(waitReplyTime), &processReply,localNode, 
		GetNodePtrFromIpv4Adr(sourceAdr,senseNodes,mobileSinkNode)->GetId(),sendNum,gatewayId); 
		NS_LOG_LOGIC(TIME_STAMP_FUC<<"Socket from "<<localAdr<<" launched!");
	} else {
		NS_LOG_LOGIC(
				TIME_STAMP_FUC <<GetNodeIpv4Address(localNode)
				<<" failed in transmitting data pkt for lack of energy");
	}
}

//-------------------------------------------------------------------------------------
bool IsVerticalRegion(double posx1, double posy1, double posx2, double posy2) {
	double dis = std::pow((posx1 - posx2) * (posx1 - posx2) + (posy1 - posy2) * (posy1 - posy2), 1.0 / 2);
	if (dis < cylinderR)
		return true;
	else
		return false;
}

//-------------------------------------------------------------------------------------
void sendCache(Ptr<Node> thisNode){
	double sendCacheNum=0;
	for(uint32_t i=0;i<NS[thisNode->GetId()].nodeCache.size();i++){
		if (NS[thisNode->GetId()].nodeCache[i].attempts != 2) {
			isRetry[NS[thisNode->GetId()].nodeCache[i].sendNum] = false;
		}
		if(NS[thisNode->GetId()].nodeCache[i].isSend==false&&NS[thisNode->GetId()].nodeCache[i].attempts>0){
			sendCacheNum++;
			Simulator::Schedule(Seconds(0), &TransmitDataPacket,thisNode, 
				mapIdAdr[NS[thisNode->GetId()].nodeCache[i].sourceId], GetNodeIpv4Address(mobileSinkNode.Get(0)),NS[thisNode->GetId()].nodeCache[i].sendNum,
				NS[thisNode->GetId()].nodeCache[i].sendTime);
			cacheTimes++;
			NS[thisNode->GetId()].nodeCache[i].isSend=true;	
			NS[thisNode->GetId()].nodeCache[i].isReceReply=false;
			NS[thisNode->GetId()].nodeCache[i].attempts--;
		}
	}
}

//-------------------------------------------------------------------------------------
void DataToSinkSecond(){
	double interval=0;
	for (NodeContainer::Iterator i = senseNodes.Begin(); i != senseNodes.End();
			i++) {
		Ptr<Node> thisNode = *i;
		deleteInvalidCache(thisNode);
		Simulator::Schedule(Seconds(interval+0.000001), &sendCache,thisNode);
		interval += 0.01;	
	}
}

//-------------------------------------------------------------------------------------
void processReply(Ptr<Node> thisNode, uint32_t sourceId,int sendNum,uint32_t gatewayId){  
	vector<dataCache>::iterator it;
 	for(it=NS[thisNode->GetId()].nodeCache.begin();it!=NS[thisNode->GetId()].nodeCache.end();){
        if(it->sourceId==sourceId&&it->sendNum==sendNum){ 
			if(it->isReceReply==false){
				if(gatewayId==mobileSinkNode.Get(0)->GetId()){
					it->isSend=false;
					send2BSFail++;
					return;
				} 
				noReplyFail++;
				int before1=getNeighNum1(thisNode->GetId());
				for (int i = 0; i < graph.m_vCount; ++i){
					int curId = graph.m_vVertex[i].id;  
					if((uint32_t)curId != thisNode->GetId())
						continue;
					Edge* edge = graph.m_vVertex[i].next;
					Edge* lastedge=edge;
					while (edge) {
						if(edge->id==(int)gatewayId){
							lastedge->next=edge->next;
							break;
						}
						lastedge=edge;
						edge = edge->next;
					}
				}
				int after1=getNeighNum1(thisNode->GetId());
				if(after1==before1)
					deleteNeighFail++;
				recvRatio[thisNode->GetId()][gatewayId] = (1 - 0.05) * recvRatio[thisNode->GetId()][gatewayId];
				recvRatio[gatewayId][thisNode->GetId()] = recvRatio[thisNode->GetId()][gatewayId];
				if(it->attempts>0){
					it->attempts--;
					if(thisNode->GetId()==sourceId)
						Simulator::Schedule(Seconds(0), &TransmitDataPacket,thisNode, 
						mapIdAdr[it->sourceId], GetNodeIpv4Address(mobileSinkNode.Get(0)),it->sendNum,
						Simulator::Now().GetMicroSeconds()); 
					else
						Simulator::Schedule(Seconds(0), &TransmitDataPacket,thisNode, 
						mapIdAdr[it->sourceId], GetNodeIpv4Address(mobileSinkNode.Get(0)),it->sendNum,
						it->sendTime); 
						cacheTimes++;
				}
				else
					it->isSend=false;
			}
			return;
		}          
        else
            ++it;  
    }
}

//-------------------------------------------------------------------------------------
void generateCache(Ptr<Node> thisNode,uint32_t sourceId,int sendNum,uint32_t sendTime){
	dataCache dCache={sourceId,sendNum,sendTime,false,false,2};
	NS[thisNode->GetId()].nodeCache.push_back(dCache); 
}

//-------------------------------------------------------------------------------------
void deleteInvalidCache(Ptr<Node> thisNode){
	vector<dataCache>::iterator it;
	 for(it=NS[thisNode->GetId()].nodeCache.begin();it!=NS[thisNode->GetId()].nodeCache.end();){
        if(Simulator::Now().GetMicroSeconds()-it->sendTime>validTime*1000000)
		{
	        it=NS[thisNode->GetId()].nodeCache.erase(it);
			deleteInvalidCacheTimes++;	
		} 
        else
            ++it; 
    }
}

//-------------------------------------------------------------------------------------
bool isExist(Ptr<Node> thisNode,int sendNum){
	vector<dataCache>::iterator it;
	for(it=NS[thisNode->GetId()].nodeCache.begin();it!=NS[thisNode->GetId()].nodeCache.end();){
        if(it->sendNum==sendNum)
			return true;
		else
			++it;
    }
	return false;
}

//-------------------------------------------------------------------------------------
void DataToSink() {
	double interval = 0;
	for(int i=0;i<201;i++){
		for(int j=0;j<201;j++)
			transState[i][j]=0;
	}
	for (NodeContainer::Iterator i = senseNodes.Begin(); i != senseNodes.End();
			i++) {
		Ptr<Node> thisNode = *i;
		deleteInvalidCache(thisNode);
		int sendNum = send + 1;
		Simulator::Schedule(Seconds(interval), &generateCache,thisNode,thisNode->GetId(),sendNum,(uint32_t)(Simulator::Now().GetMicroSeconds()+interval*1000000));
		Simulator::Schedule(Seconds(interval), &sendCache,thisNode);
		totalBytesGenerated += pktSize;
		send++;
		interval += 0.02;
	}

	if(send == maxPackets){
		lifeTime = Simulator::Now().GetSeconds();
		Simulator::Stop(Seconds(5.0));
	}
}

//-------------------------------------------------------------------------------------
int32_t ProcessDataPacket(Ptr<Node> thisNode, Ptr<Packet> packet,Ipv4Header h){
	Ipv4Address srcAdr = h.GetSource();
	Ipv4Address dstAdr =h.GetDestination();
	Ipv4Address localAdr = GetNodeIpv4Address(thisNode);
	stringstream recvData;
	packet->CopyData(&recvData, packet->GetSize());
	int sendNum = 0;
	uint32_t sendTime = 0;
	AnalyzeDataPacket(recvData,sendNum,sendTime);
	deleteInvalidCache(thisNode);
	if (localAdr != dstAdr) {
		NS_LOG_LOGIC(TIME_STAMP_FUC<<
					GetNodeIpv4Address(thisNode)<<"received a data packet from "
					<<h.GetSource()<<" to "<<h.GetDestination()<<srcAdr<<"to"<<dstAdr);
		if(!isExist(thisNode,sendNum)){
			Simulator::Schedule(Seconds(0),generateCache,thisNode,GetNodePtrFromIpv4Adr(srcAdr,senseNodes,mobileSinkNode)->GetId(),sendNum,sendTime);
		}
		Simulator::Schedule(Seconds(0),sendCache,thisNode);
		return 0;
	}
	NS_LOG_INFO(TIME_STAMP_FUC<<
						GetNodeIpv4Address(thisNode)<<"(sink) received a data packet from "
						<<h.GetSource());
	return 0;
}

//-------------------------------------------------------------------------------------
double getNeighLocInput(Ptr<Node>thisNode, uint32_t id) {
	Vector location = thisNode->GetObject<MobilityModel>()->GetPosition();
	double BS_Lx, BS_Ly, N_Lx, N_Ly, result, tmp, tmp1, tmp2;
	uint32_t  t = Simulator::Now().GetMicroSeconds();
	BS_Lx = NS[thisNode->GetId()].BS_PositionX + (double)(t - NS[thisNode->GetId()].BS_SendTime) * 0.000001 * NS[thisNode->GetId()].BS_VelocityX;
	BS_Ly = NS[thisNode->GetId()].BS_PositionY + (double)(t - NS[thisNode->GetId()].BS_SendTime) * 0.000001 * NS[thisNode->GetId()].BS_VelocityY;
	N_Lx = Node_Lx[id] + (double)(t - transTime[id]) * 0.000001 * Node_Vx[id];
	N_Ly = Node_Ly[id] + (double)(t - transTime[id]) * 0.000001 * Node_Vy[id];
	result = std::sqrt((N_Lx - location.x) * (N_Lx - location.x) + (N_Ly - location.y) * (N_Ly - location.y));
	tmp = ((BS_Lx - N_Lx) * (BS_Lx - location.x) + (BS_Ly - N_Ly) * (BS_Ly - location.y)); 
	tmp1 = std::sqrt((BS_Lx - N_Lx) * (BS_Lx - N_Lx) + (BS_Ly - N_Ly) * (BS_Ly - N_Ly)); 
	tmp2 = std::sqrt((BS_Lx - location.x) * (BS_Lx - location.x) + (BS_Ly - location.y) * (BS_Ly - location.y));
	if (tmp1 == 0 || tmp2 == 0) {
		tmp = 1;
	}
	else {
		tmp = tmp / (tmp1 * tmp2);
	}
	tmp = exp(-tmp);
	result = result * tmp;
	if (result >= 225) {
		result = 225 / 225.1;
	}
	else {
		result = result / 225;
	}
	return result;
}

//-------------------------------------------------------------------------------------
double getNeighZInput(Ptr<Node>thisNode, uint32_t id) {
	Vector location = thisNode->GetObject<MobilityModel>()->GetPosition();
	uint32_t  t = Simulator::Now().GetMicroSeconds();
	double BS_Lz, N_Lz, result, tmp;
	BS_Lz = NS[thisNode->GetId()].BS_PositionZ + (double)(t - NS[thisNode->GetId()].BS_SendTime) * NS[thisNode->GetId()].BS_VelocityZ / 1000000;
	N_Lz = Node_Lz[id] + (t - transTime[id]) * Node_Vz[id] / 1000000;
	result = (BS_Lz - location.z) * (N_Lz - location.z);
	if (result > 0) {
		tmp = 1;
	}
	else  tmp = -1;
	result = fabs(N_Lz - location.z);
	if (result >= 225) {
		result = tmp * 0.999 / 2 + 0.5;
	}
	else {
		result = (result * tmp + 225) / 450;
	}
	return result;
}

//-------------------------------------------------------------------------------------
void getNeighNum(){		
	for (int i = 0; i < graph.m_vCount; ++i) {
		int neighNum = 0;
		Edge* tmp = graph.m_vVertex[i].next;
		int curId = graph.m_vVertex[i].id;
		old_NeighNum[curId] = new_NeighNum[curId];
		while (tmp) {
			tmp = tmp->next;
			neighNum++;
		}
		new_NeighNum[curId] = neighNum;
	}
}

//-------------------------------------------------------------------------------------
int getNeighNum1(uint32_t neighId){
	int neighNum=0;
	for (int i = 0; i < graph.m_vCount; ++i){
		int curId = graph.m_vVertex[i].id;  
		if((uint32_t)curId != neighId)
			continue;
		Edge* edge = graph.m_vVertex[i].next;
		while (edge) {
			neighNum++;
			edge=edge->next;
		}
		break;
	}
	return neighNum;
}

//-------------------------------------------------------------------------------------
double getNeighVelocityInput(Ptr<Node>thisNode,uint32_t id){
	Vector Velocity = thisNode->GetObject<MobilityModel>()->GetVelocity();
	double neighVelocityValue=sqrt(pow(Node_Vx[id], 2)+pow(Node_Vy[id], 2));
	double thisNodeVelocityValue=sqrt(pow(Velocity.x, 2)+pow(Velocity.y, 2));
	double cosNeighAngle;
	if(neighVelocityValue==0||thisNodeVelocityValue==0)
		cosNeighAngle=1;
	else
		cosNeighAngle=(Node_Vx[id]*Velocity.x+Node_Vy[id]*Velocity.y)/(neighVelocityValue*thisNodeVelocityValue);
	Vector neigh2BS;
	neigh2BS.x=NS[thisNode->GetId()].BS_PositionX-Node_Lx[id];
	neigh2BS.y=NS[thisNode->GetId()].BS_PositionY-Node_Ly[id];
	neigh2BS.z=NS[thisNode->GetId()].BS_PositionZ-Node_Lz[id];
	double neigh2BSValue=sqrt(pow(neigh2BS.x, 2)+pow(neigh2BS.y, 2));
	double cosNeigh2BSAngle;
	if(neigh2BSValue==0|| neighVelocityValue ==0)
		cosNeigh2BSAngle=1;
	else
		cosNeigh2BSAngle=(Node_Vx[id]*neigh2BS.x+Node_Vy[id]*neigh2BS.y)/(neighVelocityValue *neigh2BSValue);
	if (neighVelocityValue > moveSpeed)
		neighVelocityValue = moveSpeed*0.999;
	double tmp=(neighVelocityValue*cosNeighAngle*cosNeigh2BSAngle+moveSpeed)/2/moveSpeed;
	return tmp;
}

//-------------------------------------------------------------------------------------
double calculate(Ptr<Node>thisNode, uint32_t id) {
	clock_t startC, finishC;
	startC = clock();
	if (id == 1024)
		return 1024;
	else {
		Vector Velocity = thisNode->GetObject<MobilityModel>()->GetVelocity();
		fann_type input[8];
		fann_type* calc_out;
		double result,tmp2,tmp4,tmp5;
		double tmp1 = Node_Vz[id] * NS[thisNode->GetId()].BS_VelocityZ;
		if (tmp1 > 0) {
			tmp2 = 1;
		}
		else 
			tmp2 = -1;
		if (fabs(Node_Vz[id] - Velocity.z) >= 100) {
			tmp5 = tmp2 * 0.999 / 2 + 0.5;
		}
		else {
			tmp5 = (fabs(Node_Vz[id] - Velocity.z) * tmp2 + 100) / 200;
		}
		if(old_NeighNum[id]>=20)
			tmp4=0.999;
		else
			tmp4=old_NeighNum[id]*0.05;
		input[0] = getNeighLocInput(thisNode, id) * 0.001;
		input[1] = getNeighVelocityInput(thisNode,id) * 0.001;
		input[2] = (double)NS[id].NodeLevel * 0.1;
		input[3] = getNeighZInput(thisNode,id) ;
		input[4] = tmp5;
		input[5] = tmp4;
		double tmp3 = 0;
		if (NS[id].nodeCache.size() >= 20) {
			tmp3=19.999*0.05;
		}
		else {
			tmp3= (double)(NS[id].nodeCache.size())* 0.05;
		}
		input[6] = tmp3;
		input[7] =recvRatio[thisNode->GetId()][id];
		calc_out = fann_run(ann, input);
		result = calc_out[0];
		finishC = clock();
		if (countnum < 1000) {
			caculateTime = caculateTime + (double)(finishC - startC) / CLOCKS_PER_SEC;
			countnum++;
		}
		return result;
	}
}

//-------------------------------------------------------------------------------------
uint32_t AnalyzeReplyPacket(stringstream& ss, int& sendNum, uint32_t& nodeId) {
	stringstream si;
	uint32_t sourceId=1024;
	char c[ss.str().size()];
	ss >> c;
	char* p = c;
	while (*p != '/') {
		si << *p;
		p++;
	}
	si >> sendNum;
	si.str("");
	si.clear();
	p++;
	while (*p != '/') {
		si << *p;
		p++;
	}
	si >> sourceId;
	si.str("");
	si.clear();
	p++;
	while (*p != '/') {
		si << *p;
		p++;
	}
	si >> nodeId;
	si.str("");
	si.clear();
	return sourceId;
}

//-------------------------------------------------------------------------------------
void SendReplyTransPacket(Ptr<Node>fromnode, Ptr<Node>tonode, int sendNum,uint32_t sourceId) {
	Ipv4Address sourceAdr = GetNodeIpv4Address(fromnode);
	stringstream ss;
	ss << sendNum<<"/"<<sourceId<<"/";
	stringstream pktContents(ss.str().c_str());
	Ptr<Packet> ReplyTransPkt = Create<Packet>((uint8_t*)pktContents.str().c_str(), pktContents.str().length());
	pktType pktType = Reply_Trans_Type;
	Ipv4Address toAdr = GetNodeIpv4Address(tonode);
	Ipv4Header h;
	h.SetSource(sourceAdr);
	h.SetDestination(toAdr);
	h.SetIdentification(pktType);
	ReplyTransPkt->AddHeader(h);
	InetSocketAddress Toadr = InetSocketAddress(toAdr, 80);
	Ptr<Socket> send_dataSocket = Socket::CreateSocket(fromnode, tid);
	send_dataSocket->Connect(Toadr);
	send_dataSocket->Send(ReplyTransPkt);
	uint32_t idf = fromnode->GetId();
	double oldValuef = NS[idf].remainingJ;
	Vector fromLocation = fromnode->GetObject<MobilityModel>()->GetPosition();
	Vector toLocation = tonode->GetObject<MobilityModel>()->GetPosition();
	double distance2node = GetdistanOf2Nodes(fromLocation, toLocation);
	uint32_t thisPktSize = 100;
	double consumedJf;
	if (distance2node >= d0)
		consumedJf = ETX * thisPktSize + Emp * thisPktSize * (pow(distance2node, 4));
	else
		consumedJf = ETX * thisPktSize + Efs * thisPktSize * (pow(distance2node, 2));
	if (oldValuef > consumedJf) {
		NS[idf].remainingJ -= consumedJf;
		totalConsumed = totalConsumed + consumedJf;
	}
	else {
		NS[idf].isdead = true;
		NS[idf].remainingJ = 0;
	}
	send_dataSocket->Close();
}

//-------------------------------------------------------------------------------------
uint32_t AnalyzeDataPacket(stringstream& ss, int& sendNum, uint32_t& sendTime) {
	stringstream si;
	uint32_t nodeID;
	char c[ss.str().size()];
	ss >> c;
	char* p = c;
	while (*p != '/') {
		si << *p;
		p++;
	}
	si >> sendNum;
	si.str("");
	si.clear();
	p++;
	while (*p != '/') {
		si << *p;
		p++;
	}
	si >> sendTime;
	si.str("");
	si.clear();
	p++;
	while (*p != '/') {
		si << *p;
		p++;
	}
	si >> nodeID;
	si.str("");
	si.clear();
	return nodeID;
}

//-------------------------------------------------------------------------------------
double GetdistanOf2Nodes(Vector one,Vector two) {
	return std::pow((one.x - two.x)*(one.x - two.x) + (one.y - two.y)*(one.y - two.y)+(one.z - two.z)*(one.z - two.z),1.0/2);
}

//-------------------------------------------------------------------------------------
double GetdistanOf2Id(uint32_t id1,uint32_t id2){
	Ptr<Node>thisNode = GetNodePtrFromGlobalId(id1,senseNodes,mobileSinkNode);
	Ptr<Node>gatewayNode = GetNodePtrFromGlobalId(id2,senseNodes,mobileSinkNode);
	Vector location1;
	Vector location2;
	if (isStatic) {
		location1 = thisNode->GetObject<MobilityModel>()->GetPosition();
		location2 = gatewayNode->GetObject<MobilityModel>()->GetPosition();
	}else{
		location1 = thisNode->GetObject<MobilityModel>()->GetPosition();
		if(id2 == mobileSinkNode.Get(0)->GetId()){
			location2 = gatewayNode->GetObject<MobilityModel>()->GetPosition();
		}else{
			location2 = gatewayNode->GetObject<MobilityModel>()->GetPosition();
		}
	}
	return GetdistanOf2Nodes(location1,location2);
}








}