#include "global.h"
#include "ns3/node-container.h"
#include <iomanip>
#include "ns3/mobility-module.h"

using namespace std;

extern double maxDis;
extern string thisSimPath;
extern string exeName;
namespace ns3 {

NS_LOG_COMPONENT_DEFINE("Global");

//-------------------------------------------------------------------------------------
void FindInrangeNodes(NodeContainer allNodes) {
	uint32_t num = allNodes.GetN();
	NS_LOG_LOGIC(FUC<<"num="<<num);
	uint32_t inrangeStat[num] = { 0 };
	uint32_t index=0;
	Ptr<Node> srcN, remN;
	for (NodeContainer::Iterator i = allNodes.Begin(); i != allNodes.End();
			i++) {
		srcN = *i;
		for (NodeContainer::Iterator j = allNodes.Begin(); j != allNodes.End();
				j++) {
			remN = *j;
			if (GetDistanceOf2Nodes(srcN, remN) < maxDis) {
				inrangeStat[index]++;
			}
		}
		index++;
	}
	stringstream ss;
	ss << thisSimPath<<exeName<<"-inrange-nodes.stat";
	ofstream of(ss.str().c_str());
	ss << std::endl;
	ss << std::setw(20) << std::left << "Node ID(Global)";
	ss << std::setw(20) << std::left << "Num of Inrange Nodes" << std::endl;
	stringstream si;
	for (uint32_t i = 0; i < num; i++) {
		si << allNodes.Get(i)->GetId();
		ss << std::setw(20) << std::left << si.str();
		si.str("");
		si.clear();

		si << --inrangeStat[i];
		ss << std::setw(20) << std::left << si.str() << std::endl;
		si.str("");
		si.clear();
	}
	NS_LOG_INFO(ss.str().c_str());
	of << ss.str().c_str();
	of.close();
}

//-------------------------------------------------------------------------------------
inline double GetDistanceOf2Nodes(Ptr<Node> srcN, Ptr<Node> remN) {
	Ptr<ConstantPositionMobilityModel> srcCpmm = srcN->GetObject<
			ConstantPositionMobilityModel>();
	Ptr<ConstantPositionMobilityModel> remCpmm = remN->GetObject<
			ConstantPositionMobilityModel>();
	Vector srcP = srcCpmm->GetPosition();
	Vector remP = remCpmm->GetPosition();
	return std::sqrt((srcP.x - remP.x)*(srcP.x - remP.x) + (srcP.y - remP.y)*(srcP.y - remP.y));
}


enum nodeType CheckNodeType(Ptr<Node> node,NodeContainer senseNodes,Ptr<Node> mobilenode) {
	if(node->GetId()==mobilenode->GetId())
		return mobileSink_Type;
	return sense_Type;
}

//-------------------------------------------------------------------------------------
Ptr<Node> GetNodePtrFromGlobalId(uint32_t id, NodeContainer n,NodeContainer mobileSinkNode) {
	for (uint32_t i = 0; i < n.GetN(); i++) {
		if (n.Get(i)->GetId() == id) {
			return n.Get(i);
		}
	}
	return mobileSinkNode.Get(0);
}

//-------------------------------------------------------------------------------------
double RandomDoubleVauleGenerator(double min, double max) {

	Ptr<UniformRandomVariable> r = CreateObject<UniformRandomVariable>();
	r->SetAttribute("Min", DoubleValue(min));
	r->SetAttribute("Max", DoubleValue(max));
	return r->GetValue();
}

//-------------------------------------------------------------------------------------
Ipv4Address GetNodeIpv4Address(Ptr<Node> n){
	return n->GetObject<Ipv4>()->GetAddress(1,0).GetLocal();
}

//-------------------------------------------------------------------------------------
Ptr<Node> GetNodePtrFromIpv4Adr(Ipv4Address adr,NodeContainer senseNodes,NodeContainer mobileSinkNode) {
	for (NodeContainer::Iterator i = senseNodes.Begin(); i != senseNodes.End();
			i++) {
		Ptr<Node> n = *i;
		if (GetNodeIpv4Address(n) == adr) {
			NS_LOG_LOGIC("GetNodePtrFromIpv4Adr: senseNodes matched!");
			return n;
		}
	}
	NS_LOG_LOGIC("GetNodePtrFromIpv4Adr: mobileSinkNode matched!");
	return mobileSinkNode.Get(0);
}

}
