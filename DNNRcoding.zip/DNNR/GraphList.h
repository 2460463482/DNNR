#ifndef GraphListL_H
#define GraphList_H
#include <iostream>
#include <cstdio>
 
using namespace std;
namespace ns3 {
//-------------------------------------------------------------------------------------
struct Edge{
	int id;
	double weight;
	struct Edge* next;
};

//-------------------------------------------------------------------------------------
struct Vertex{
	int id;
	struct Edge* next;
};

//-------------------------------------------------------------------------------------
class GraphList
{
public:
	~GraphList();
	void createGraph();
	void printGraph();
	void updateArray();
	void clear();
	void addEdgeToList(int vFrom, double weight, int vTo);
	void inputVertexCount();
	void makeVertexArray();
	void print();
	void clearNode(uint32_t id);
	void addNewEdgeToList(int vFrom, double weight, int vTo);
	bool isExist(int vFrom, int vTo);
	void printNoteNeighbor(uint32_t id);
 
private:
	void inputEdgeCount();
	void inputEdgeInfo();
	

public:
	int m_vCount;
	int m_eCount;
	int adjcent_Matrix[11][11]={};
	Vertex* m_vVertex;
};


}

#endif